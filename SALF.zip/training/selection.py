"""Choose backbone/epochs by 5-fold inner validation only; never use outer test."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from SALF.models.registry import SALF_NAMES
from SALF.data.io import write_json,sha

def choose(dataset,outer_fold,output,max_epochs=100):
    root=Path(output)/dataset/f'outer_{outer_fold:02d}'
    records=[]
    for inner in range(1,6):
        for name in SALF_NAMES:
            folder=root/'inner'/f'inner_{inner:02d}'/name
            path=folder/'kd'/'done.json'
            if not path.is_file():
                raise FileNotFoundError(f'Missing 5-fold four-backbone KD result: {path}')
            info=json.loads(path.read_text(encoding='utf-8'))
            record={'backbone':name,'inner':inner,'score':float(info['score'])}
            for stage in ['teacher','base','kd']:
                cp=folder/stage/'done.json'
                if not cp.is_file():raise FileNotFoundError(cp)
                record[stage+'_epoch']=int(json.loads(cp.read_text(encoding='utf-8'))['epoch'])
            records.append(record)
    df=pd.DataFrame(records)
    means=df.groupby('backbone')['score'].mean().sort_values(ascending=False)
    chosen=means.index[0]
    selected=df.loc[df.backbone==chosen]
    eps={s:int(np.clip(round(selected[s+'_epoch'].median()),1,max_epochs)) for s in ['teacher','base','kd']}
    splits=root.parent/'split_assignments.csv'
    if not splits.is_file():raise FileNotFoundError(splits)
    result={'dataset':dataset,'outer_fold':outer_fold,'chosen':chosen,'best_epochs':eps,
        'inner_five_mean_macro_f1':means.to_dict(),'split_sha256':sha(splits),
        'rule':'Highest five-inner mean NS validation Macro-F1; median selected epochs; no outer-test',
        'class_mapping':{'0':'Awake','1':'Optimal','2':'Excessive'}}
    write_json(root/'selection.json',result)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return result

def load_selection(dataset,outer_fold,output):
    root=Path(output)/dataset/f'outer_{outer_fold:02d}'
    path=root/'selection.json'
    if not path.is_file():raise FileNotFoundError(f'Run select after 4 x 5 inner folds: {path}')
    result=json.loads(path.read_text(encoding='utf-8'))
    if result.get('split_sha256')!=sha(root.parent/'split_assignments.csv'):
        raise ValueError('Selected fold assignment changed; refuse to load prior selection')
    return result
