# Modularity refactor: bodies below extracted from original source without changing training equations.
import copy, gc, json, os, random
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.nn import functional as F
from sklearn.metrics import accuracy_score, balanced_accuracy_score, confusion_matrix, f1_score, precision_recall_fscore_support
from sklearn.model_selection import KFold
from torch.utils.data import DataLoader,TensorDataset
from SALF.models.registry import SALF_NAMES, create
from SALF.data.io import write_json
def set_seed(seed):
 random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
 if torch.cuda.is_available():torch.cuda.manual_seed_all(seed)

def norm_fit(arr):
 """Only training data. PSD columns; raw per-channel global scale from current training partition."""
 psd=arr['X'];mu=psd.mean(axis=(0,1),keepdims=True);std=np.maximum(psd.std(axis=(0,1),keepdims=True),1e-5)
 raw_stats=None
 if 'raw' in arr:
  raw=arr['raw'];raw_stats=(raw.mean(axis=(0,2),keepdims=True),np.maximum(raw.std(axis=(0,2),keepdims=True),1e-5))
 return mu,std,raw_stats

def normalize(arr,stat):
 mu,std,rs=stat;res={k:v for k,v in arr.items()};res['X']=np.clip((arr['X']-mu)/std,-12,12).astype('float32')
 if 'raw' in arr:
  if rs is None:
   # The current model was trained without raw; discard test-only raw instead of
   # trying to normalize it using nonexistent training statistics.
   res.pop('raw',None)
  else:
   res['raw']=np.clip((arr['raw']-rs[0])/rs[1],-12,12).astype('float32')
 return res

def validate_groups(a,b,outer_ids):
 aa=set(a['sid']);bb=set(b['sid']);tt=set(outer_ids)
 if aa & bb or aa & tt or bb & tt:raise AssertionError('SUBJECT LEAKAGE detected')

def kind_of(*arrs):
 if all('raw' in a for a in arrs):return 'raw2' if all(a['raw'].shape[1]==2 for a in arrs) else 'raw1'
 return 'spectral'

def tensors(arr):
 x=torch.from_numpy(arr['X']).float();y=torch.from_numpy(arr['y']).long()
 raw=torch.from_numpy(arr.get('raw',np.zeros((len(y),1,1),dtype='float32'))).float()
 return TensorDataset(x,raw,y)

def train_epoch(model,train,device,opt,bs,teacher=None,hard=.3,soft=.2,feature=.5,T=2,selection=False):
 model.train();loader=DataLoader(tensors(train),batch_size=bs,shuffle=True,num_workers=0)
 if teacher is not None:teacher.eval()
 tot=0;n=0
 for x,raw,y in loader:
  x=x.to(device);raw=raw.to(device);y=y.to(device)
  if raw.size(-1)==1:raw=None
  z,h=model(x,raw)
  if teacher is None:
   if selection:
    losses=F.cross_entropy(z,y,reduction='none')
    # Paper-guided lightweight *train-only* informative-data priority:
    # reward samples whose learned representation differs from the batch
    # centroid, but temper extremely high-loss examples as possible artifacts.
    # This is NOT the authors' BYOL/DGF/REINFORCE selection algorithm.
    feat=F.normalize(h.detach(),dim=-1)
    centre=F.normalize(feat.mean(dim=0),dim=0)
    novelty=(1-(feat*centre).sum(-1)).clamp(min=0)
    weights=(0.5+novelty/(novelty.mean()+1e-6)).clamp(0.5,2.0)
    robust=torch.where(losses.detach()>torch.quantile(losses.detach(),.95),0.5,1.0)
    loss=(weights*robust*losses).sum()/weights.sum().clamp_min(1e-6)
   else:loss=F.cross_entropy(z,y)
  else:
   with torch.no_grad():zt,ht=teacher(x,raw)
   hard_loss=F.cross_entropy(z,y)
   soft_loss=F.kl_div(F.log_softmax(z/T,dim=-1),F.softmax(zt/T,dim=-1),reduction='batchmean')*(T*T)
   # Align latent features if same architecture. Normalized embeddings limit scale sensitivity.
   f_loss=F.mse_loss(F.normalize(h,dim=1),F.normalize(ht,dim=1))
   loss=hard*hard_loss+soft*soft_loss+feature*f_loss
  opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.0);opt.step()
  tot+=loss.item()*len(y);n+=len(y)
 return tot/max(n,1)

@torch.no_grad()
def predict(model,arr,device,bs):
 model.eval();out=[]
 for x,raw,y in DataLoader(tensors(arr),batch_size=bs,shuffle=False):
  x=x.to(device);raw=raw.to(device)
  if raw.size(-1)==1:raw=None
  z,_=model(x,raw);out.append(z.softmax(-1).cpu().numpy())
 return np.concatenate(out)

def metr(y,p):
 yp=p.argmax(1);pr,rec,f1,support=precision_recall_fscore_support(y,yp,labels=[0,1,2],zero_division=0)
 cm=confusion_matrix(y,yp,labels=[0,1,2]);sp=[]
 for k in range(3):
  tp=cm[k,k];fn=cm[k].sum()-tp;fp=cm[:,k].sum()-tp;tn=cm.sum()-tp-fn-fp
  sp.append(float(tn/(tn+fp)) if tn+fp else None)
 return {'accuracy':float(accuracy_score(y,yp)),'balanced_accuracy':float(balanced_accuracy_score(y,yp)) if len(set(y))==3 else float(np.mean(rec)), 'macro_f1':float(f1.mean()),'precision':pr.tolist(),'recall':rec.tolist(),'class_f1':f1.tolist(),'specificity':sp,'support':support.tolist(),'confusion':cm.tolist(),'absent_true_classes':sorted(set([0,1,2])-set(y.tolist()))}

def internal_scores(model,arr,device,bs):return metr(arr['y'],predict(model,arr,device,bs))

def subset(arr,phen):return {k:v[arr['phen']==phen] for k,v in arr.items()}

def train_simple(name,tr,va,kind,device,params,seed,path,teacher=None,initialize=None):
 """Input data already transformed with ONE shared inner-train normalization; no test data used."""
 path=Path(path);path.mkdir(parents=True,exist_ok=True)
 if (path/'done.json').is_file():
  rec=json.loads((path/'done.json').read_text());model=create(name,kind).to(device)
  model.load_state_dict(torch.load(path/'best.pt',map_location=device,weights_only=True));return model,rec
 set_seed(seed);model=create(name,kind).to(device)
 if initialize is not None:model.load_state_dict(copy.deepcopy(initialize.state_dict()))
 if teacher is not None:
  teacher.eval()
  for p in teacher.parameters():p.requires_grad_(False)
 optim=torch.optim.Adam(model.parameters(),lr=params['lr'])
 best=-1;pat=0;bestep=1;rows=[]
 for ep in range(1,params['epochs']+1):
  loss=train_epoch(model,tr,device,optim,params['batch_size'],teacher,params['hard'],params['soft'],params['feature'],params['temperature'],selection=(name=='anesformer'))
  score=internal_scores(model,va,device,params['batch_size'])['macro_f1']
  rows.append([ep,loss,score])
  if score>best+1e-9:best=score;bestep=ep;pat=0;torch.save(model.state_dict(),path/'best.pt')
  else:pat+=1
  if pat>=params['patience']:break
 model.load_state_dict(torch.load(path/'best.pt',map_location=device,weights_only=True))
 pd.DataFrame(rows,columns=['epoch','loss','val_macro_f1']).to_csv(path/'history.csv',index=False)
 rec={'score':best,'epoch':bestep,'seed':seed,'n_train':len(tr['y']),'n_validation':len(va['y'])};write_json(path/'done.json',rec)
 return model,rec

def train_fixed(name,tr,kind,device,params,seed,ep,path,teacher=None,initialize=None):
 path=Path(path);path.mkdir(parents=True,exist_ok=True)
 if (path/'done.json').exists():
  m=create(name,kind).to(device);m.load_state_dict(torch.load(path/'model.pt',map_location=device,weights_only=True));return m
 set_seed(seed);m=create(name,kind).to(device)
 if initialize is not None:m.load_state_dict(copy.deepcopy(initialize.state_dict()))
 if teacher is not None:
  teacher.eval()
  for p in teacher.parameters():p.requires_grad_(False)
 opt=torch.optim.Adam(m.parameters(),lr=params['lr'])
 for _ in range(max(1,int(ep))):train_epoch(m,tr,device,opt,params['batch_size'],teacher,params['hard'],params['soft'],params['feature'],params['temperature'],selection=(name=='anesformer'))
 torch.save(m.state_dict(),path/'model.pt');write_json(path/'done.json',{'epochs':int(ep),'seed':seed,'n_train':len(tr['y'])})
 return m

def inner_subject_folds(df,dev_sids,seed):
 df=df[df.subject_id.astype(str).isin(dev_sids)]
 blocks={}
 for p in ('S','NS'):
  ls=sorted(df.loc[df.phenotype==p,'subject_id'].astype(str).tolist())
  if len(ls)<5:raise ValueError('Not enough subjects for SALF inner 5-fold')
  blocks[p]=[(np.array(ls)[tr].tolist(),np.array(ls)[va].tolist()) for tr,va in KFold(5,shuffle=True,random_state=seed).split(ls)]
 for i in range(5):
  yield blocks['S'][i][0],blocks['S'][i][1],blocks['NS'][i][0],blocks['NS'][i][1]
