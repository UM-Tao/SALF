"""Train-only orchestration around original R1C5_v2 inner/final kernels. No outer-test inference.

Training stages may be run separately. Stage-specific output checkpoint names and
normalization are frozen. Never use held-out outer test subjects for fitting/selection.
"""
import json
from pathlib import Path
import numpy as np
import torch
from SALF.data.io import load_metadata, check_frozen_cohort, check_npz, split_file, get_fold, cache_dataset, write_json
from SALF.models.registry import SALF_NAMES,create
from SALF.data.labels import CLASS_NAMES,SCHEMA_ID
from .core import (set_seed,norm_fit,normalize,kind_of,subset,inner_subject_folds,train_simple,train_fixed)

DEFAULT_ROOT = '/home/ftq/HBA/project/9.9-responce/R1C5_Anes_SQI_FEHANet/data'
DEFAULT_OUTPUT = '/home/ftq/HBA/project/SALF_Modular_RUN'

def _json_ready(d):
    return {k:(str(v) if isinstance(v,Path) else v) for k,v in d.items()}

def frozen_protocol(path,record):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        previous=json.loads(path.read_text(encoding='utf-8'))
        if previous!=record:
            raise RuntimeError(f'Existing frozen configuration differs: {path}; use a new output directory.')
    else:write_json(path,record)

def load_saved(name,folder,device,final=False):
    folder=Path(folder)
    f=folder/('model.pt' if final else 'best.pt')
    if not f.exists():raise FileNotFoundError(f'First train prerequisite stage: {f}')
    m=create(name).to(device)
    m.load_state_dict(torch.load(f,map_location=device,weights_only=True))
    return m

def make_dataset(data_root,dataset,output,seed,outer_fold):
    df=load_metadata(data_root,dataset)
    check_frozen_cohort(data_root,dataset,df)
    # Strict input checks read real NPZ files but never use outer test data for fitting.
    ledger,_=check_npz(data_root,dataset,df,strict=True)
    # Freeze exact input-file hashes and phenotype assignments; a new cohort needs NEW output.
    assignment_manifest=Path(data_root)/dataset/'group_assignment.json'
    assignment_hash=__import__('hashlib').sha256(assignment_manifest.read_bytes()).hexdigest() if assignment_manifest.exists() else ''
    fingerprint=__import__("hashlib").sha256((ledger.sort_values(["phenotype","subject_id"]).to_csv(index=False)+assignment_hash).encode()).hexdigest()
    dsout=Path(output)/dataset
    frozen_protocol(dsout/"cohort_signature.json",{"dataset":dataset,"sha256":fingerprint,"assignment_provenance_sha256":assignment_hash,"S":int((df.phenotype=="S").sum()),"NS":int((df.phenotype=="NS").sum()),"subjects":df[["subject_id","phenotype","file"]].to_dict(orient="records")})
    # Keep a frozen mapping beside weights so sample files can be traced after training.
    current=dsout/"cohort_sources.csv"
    if not current.exists():ledger.to_csv(current,index=False)
    split=split_file(dsout/'split_assignments.csv',df,seed)
    dev,test=get_fold(split,outer_fold)
    return df,dev,test

def run_inner(*,dataset,backbone,stage,data_root,output,outer_fold=1,inner_fold=1,seed=42,
              device='cuda:0',epochs=100,patience=15,lr=5e-5,batch_size=64,
              temperature=2.0,hard=.30,soft=.20,feature=.50):
    if backbone not in SALF_NAMES:raise ValueError(backbone)
    if stage not in ('teacher','base','kd','all'):raise ValueError(stage)
    if not (1<=outer_fold<=10):raise ValueError('outer_fold must be 1..10')
    if not (1<=inner_fold<=5):raise ValueError('inner_fold must be 1..5')
    if device.startswith('cuda') and not torch.cuda.is_available():raise RuntimeError('CUDA unavailable; use --device cpu')
    df,dev,test=make_dataset(data_root,dataset,output,seed,outer_fold)
    splits=list(inner_subject_folds(df,dev,seed+outer_fold))
    s_tr,s_va,n_tr,n_va=splits[inner_fold-1]
    tr_all=cache_dataset(data_root,dataset,df,s_tr+n_tr)
    va_all=cache_dataset(data_root,dataset,df,s_va+n_va)
    kind=kind_of(tr_all,va_all)
    stats=norm_fit(tr_all)
    tr=normalize(tr_all,stats);va=normalize(va_all,stats)
    arrays={'teacher':(subset(tr,'S'),subset(va,'S')),
            'base':(subset(tr,'NS'),subset(va,'NS')),
            'kd':(subset(tr,'NS'),subset(va,'NS'))}
    folder=Path(output)/dataset/f'outer_{outer_fold:02d}'/'inner'/f'inner_{inner_fold:02d}'/backbone
    folder.mkdir(parents=True,exist_ok=True)
    protocol=dict(dataset=dataset,backbone=backbone,outer_fold=outer_fold,inner_fold=inner_fold,
        seed=seed,epochs=epochs,patience=patience,lr=lr,batch_size=batch_size,
        hard=hard,soft=soft,feature=feature,temperature=temperature,
        train_s=s_tr,train_ns=n_tr,val_s=s_va,val_ns=n_va,kind=kind,
        label_schema=SCHEMA_ID,class_names=CLASS_NAMES)
    frozen_protocol(folder/'training_protocol.json',protocol)
    np.savez(folder/'scaler.npz',mu=stats[0],std=stats[1],
        raw_mu=stats[2][0] if stats[2] is not None else np.array([]),
        raw_std=stats[2][1] if stats[2] is not None else np.array([]))
    params=dict(epochs=epochs,patience=patience,lr=lr,batch_size=batch_size,
                hard=hard,soft=soft,feature=feature,temperature=temperature)
    index=SALF_NAMES.index(backbone)
    stages=('teacher','base','kd') if stage=='all' else (stage,)
    results={}
    for name in stages:
        teacher=load_saved(backbone,folder/'teacher',device) if name=='kd' else None
        base=load_saved(backbone,folder/'base',device) if name=='kd' else None
        ss={'teacher':0,'base':1,'kd':2}[name]
        training,val=arrays[name]
        model,rec=train_simple(backbone,training,val,kind,device,params,
            seed+outer_fold+inner_fold*100+index+ss,
            folder/name,teacher=teacher,initialize=base)
        results[name]=rec
        print(f'{dataset} outer={outer_fold} inner={inner_fold} {backbone} {name}: saved {folder/name}/best.pt',flush=True)
        del model,teacher,base
    return results

def run_final(*,dataset,backbone,stage,data_root,output,outer_fold=1,seed=42,
              device='cuda:0',teacher_epochs=30,base_epochs=30,kd_epochs=30,
              lr=5e-5,batch_size=64,temperature=2.0,hard=.30,soft=.20,feature=.50):
    """Train on outer-development subjects only; fixed epoch counts are explicit.
    This is not the original automated 5-inner model selection, which chooses
    backbone/epochs from saved 5-inner validation. Supply values from that process.
    """
    if backbone not in SALF_NAMES:raise ValueError(backbone)
    if stage not in ('teacher','base','kd','all'):raise ValueError(stage)
    if device.startswith('cuda') and not torch.cuda.is_available():raise RuntimeError('CUDA unavailable')
    df,dev,test=make_dataset(data_root,dataset,output,seed,outer_fold)
    all_train=cache_dataset(data_root,dataset,df,dev)
    stats=norm_fit(all_train)
    tr=normalize(all_train,stats)
    kind=kind_of(all_train)
    folder=Path(output)/dataset/f'outer_{outer_fold:02d}'/'final'/backbone
    folder.mkdir(parents=True,exist_ok=True)
    frozen_protocol(folder/'training_protocol.json',dict(dataset=dataset,backbone=backbone,outer_fold=outer_fold,
        seed=seed,teacher_epochs=teacher_epochs,base_epochs=base_epochs,kd_epochs=kd_epochs,
        lr=lr,batch_size=batch_size,temperature=temperature,hard=hard,soft=soft,feature=feature,
        dev_subjects=dev,kind=kind,label_schema=SCHEMA_ID,class_names=CLASS_NAMES))
    np.savez(folder/'scaler.npz',mu=stats[0],std=stats[1],
        raw_mu=stats[2][0] if stats[2] is not None else np.array([]),
        raw_std=stats[2][1] if stats[2] is not None else np.array([]))
    params=dict(lr=lr,batch_size=batch_size,temperature=temperature,hard=hard,soft=soft,feature=feature)
    stages=('teacher','base','kd') if stage=='all' else (stage,)
    for name in stages:
        teacher=load_saved(backbone,folder/'teacher',device,final=True) if name=='kd' else None
        base=load_saved(backbone,folder/'base',device,final=True) if name=='kd' else None
        epochs={'teacher':teacher_epochs,'base':base_epochs,'kd':kd_epochs}[name]
        arr=subset(tr,'S' if name=='teacher' else 'NS')
        model=train_fixed(backbone,arr,kind,device,params,seed+outer_fold*200+{'teacher':1000,'base':1001,'kd':1002}[name],
            epochs,folder/name,teacher=teacher,initialize=base)
        print(f'{dataset} final outer={outer_fold} {backbone} {name}: saved {folder/name}/model.pt',flush=True)
        del model,teacher,base
