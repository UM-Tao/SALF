import argparse
from pathlib import Path

def build():
    ap=argparse.ArgumentParser(prog='python -m SALF',description='SALF modular training only')
    p=ap.add_subparsers(dest='command',required=True)
    train=p.add_parser('train',help='Train one backbone and stage; inner or final outer-development')
    train.add_argument('--dataset',required=True,choices=['OBA','HBA','VitalDB'])
    train.add_argument('--backbone',required=True,choices=['transformer','lstm','graph','vaal','auto'])
    train.add_argument('--stage',required=True,choices=['teacher','base','kd','all'])
    train.add_argument('--split',choices=['inner','final'],default='inner')
    train.add_argument('--data-root',required=True,help='Folder-driven per-dataset root with S/NS subject NPZ')
    train.add_argument('--output',required=True,help='Output directory; existing results are not overwritten')
    train.add_argument('--outer-fold',type=int,default=1,help='1..10')
    train.add_argument('--inner-fold',default='1',help='1..5 or all; inner split only')
    train.add_argument('--device',default='cuda:0');train.add_argument('--seed',type=int,default=42)
    train.add_argument('--epochs',type=int,default=100);train.add_argument('--patience',type=int,default=15)
    train.add_argument('--lr',type=float,default=5e-5);train.add_argument('--batch-size',type=int,default=64)
    train.add_argument('--temperature',type=float,default=2.0)
    train.add_argument('--hard',type=float,default=.30);train.add_argument('--soft',type=float,default=.20)
    train.add_argument('--feature',type=float,default=.50)
    train.add_argument('--teacher-epochs',type=int,default=30)
    train.add_argument('--base-epochs',type=int,default=30)
    train.add_argument('--kd-epochs',type=int,default=30)

    select=p.add_parser('select',help='Choose backbone and epochs from complete 4 x 5 inner folds')
    select.add_argument('--dataset',required=True,choices=['OBA','HBA','VitalDB'])
    select.add_argument('--outer-fold',type=int,default=1)
    select.add_argument('--output',required=True)
    select.add_argument('--max-epochs',type=int,default=100)

    rf=p.add_parser('rf',help='Fit sensitivity RF from five features per subject')
    rf.add_argument('--dataset',required=True,choices=['OBA','HBA','VitalDB'])
    rf.add_argument('--feature-table',required=True)
    rf.add_argument('--output',required=True)
    rf.add_argument('--id-col',default=None)
    rf.add_argument('--feature-cols',nargs=5,default=None)
    rf.add_argument('--seed',type=int,default=42)
    rf.add_argument('--allow-partial',action='store_true',help='Deprecated; no frozen patient list')
    rf.add_argument('--reference-labels',help='CSV/XLSX with subject_id and reference phenotype, if not in feature table')
    rf.add_argument('--label-col',help='Column containing reference S/NS phenotype')

    prep=p.add_parser('prepare',help='Generate subject-level NPZ from original signals/caches')
    prep.add_argument('--dataset',required=True,choices=['OBA','HBA','VitalDB'])
    prep.add_argument('--output',required=True,help='Data root containing OBA/, HBA/, VitalDB/')
    prep.add_argument('--source',required=True,help='OBA PSD-label ZIP; HBA original CSV folder; VitalDB any selected-case CSV/XLSX')
    prep.add_argument('--cache-dir',help='VitalDB <caseid>.npz cache directory')
    prep.add_argument('--stride',type=int,default=1)
    prep.add_argument('--source-label-order',choices=['canonical','reversed'],default='canonical',help='OBA source TXT labels; default already 0 Awake/1 Optimal/2 Excessive')
    prep.add_argument('--cache-label-order',choices=['canonical','reversed'],default='reversed',help='VitalDB cached DoA labels; reversed=0 Excessive,1 Optimal,2 Awake')
    prep.add_argument('--allow-length-trim',action='store_true')

    group=p.add_parser('group',help='Copy incoming per-subject NPZ into S/NS, tracking assignment provenance')
    group.add_argument('--dataset',required=True,choices=['OBA','HBA','VitalDB'])
    group.add_argument('--data-root',required=True)
    group.add_argument('--feature-table',required=True,help='One row/subject, five early EEG features (plus reference labels if reference grouping)')
    group.add_argument('--assignment',choices=['reference','predicted'],default='reference')
    group.add_argument('--rf-model',help='Saved .joblib model for predicted groups')
    group.add_argument('--reference-labels',help='Additional CSV/XLSX with reference S/NS labels')
    group.add_argument('--id-col');group.add_argument('--label-col')
    group.add_argument('--allow-training-subject-predictions',action='store_true',help='Explicit opt-in to exploratory in-sample predicted grouping')

    migrate=p.add_parser('migrate-labels',help='Copy NPZ files and convert reversed labels to canonical IDs')
    migrate.add_argument('--dataset',required=True,choices=['OBA','HBA','VitalDB'])
    migrate.add_argument('--source-root',required=True);migrate.add_argument('--output-root',required=True)
    migrate.add_argument('--from-order',choices=['canonical','reversed'],default='reversed')
    stamp=p.add_parser('label-stamp',help='Declare an already-canonical manually prepared NPZ root; requires user to verify class mapping first')
    stamp.add_argument('--dataset',required=True,choices=['OBA','HBA','VitalDB'])
    stamp.add_argument('--data-root',required=True)
    early=p.add_parser('rf-features',help='Dataset-specific early RF feature table generation/verification')
    early.add_argument('--dataset',required=True,choices=['OBA','HBA','VitalDB'])
    early.add_argument('--feature-table',help='OBA/HBA precomputed five early EEG features')
    early.add_argument('--cohort-root',help='VitalDB .vital root')
    early.add_argument('--cases',help='VitalDB case table containing four onset times')
    early.add_argument('--output',required=True)
    scan=p.add_parser('scan',help='Scan S/NS folders, validate subjects, save traceable source manifest')
    scan.add_argument('--dataset',required=True,choices=['OBA','HBA','VitalDB'])
    scan.add_argument('--data-root',required=True)
    scan.add_argument('--refresh',action='store_true',help='Explicitly rewrite stale manifest (never updates training outputs)')

    return ap

def main():
    args=build().parse_args()
    if args.command=='select':
        from SALF.training.selection import choose
        choose(args.dataset,args.outer_fold,args.output,args.max_epochs)
    elif args.command=='rf':
        from SALF.sensitivity.train import train
        train(args.dataset,args.feature_table,args.output,args.feature_cols,args.id_col,args.seed,args.allow_partial,
              args.reference_labels,args.label_col)
    elif args.command=='scan':
        from SALF.data.grouping import save_scan
        save_scan(args.data_root,args.dataset,args.refresh)
    elif args.command=='group':
        from SALF.data.grouping import assign_groups
        assign_groups(dataset=args.dataset,data_root=args.data_root,feature_table=args.feature_table,
            assignment=args.assignment,rf_model=args.rf_model,reference_file=args.reference_labels,
            id_col=args.id_col,label_col=args.label_col,
            allow_training_subject_predictions=args.allow_training_subject_predictions)
    elif args.command=='rf-features':
        if args.dataset=='VitalDB':
            from SALF.datasets.vitaldb.sensitivity_features import extract
            if not args.cohort_root:raise ValueError('--cohort-root required for VitalDB')
            extract(args.cohort_root,args.output,args.cases)
        else:
            if not args.feature_table:raise ValueError('--feature-table required for OBA/HBA: source first-10-min features')
            if args.dataset=='OBA':from SALF.datasets.oba.sensitivity_features import validate_feature_table
            else:from SALF.datasets.hba.sensitivity_features import validate_feature_table
            validate_feature_table(args.feature_table,args.output)
    elif args.command=='migrate-labels':
        from SALF.data.labels import migrate
        migrate(args.dataset,args.source_root,args.output_root,args.from_order)
    elif args.command=='label-stamp':
        from SALF.data.labels import stamp
        stamp(args.dataset,args.data_root)
    elif args.command=='prepare':
        if args.dataset=='OBA':
            from SALF.datasets.oba.preprocessing import prepare_oba_zip
            prepare_oba_zip(args.source,args.output,args.stride,args.source_label_order)
        elif args.dataset=='HBA':
            from SALF.datasets.hba.preprocessing import export_hba
            export_hba(args.source,args.output,args.stride,args.allow_length_trim)
        else:
            if not args.cache_dir:raise ValueError('--cache-dir required for VitalDB')
            from SALF.datasets.vitaldb.preprocessing import export_vitaldb
            export_vitaldb(args.source,args.cache_dir,args.output,args.stride,args.cache_label_order)
    elif args.command=='train':
        from SALF.training.stages import run_inner,run_final
        backbone='SALF_'+args.backbone if args.backbone!='auto' else None
        if args.backbone=='auto':
            if args.split!='final':raise ValueError('--backbone auto requires --split final')
            from SALF.training.selection import load_selection
            selected=load_selection(args.dataset,args.outer_fold,args.output)
            backbone=selected['chosen']
            args.teacher_epochs=selected['best_epochs']['teacher']
            args.base_epochs=selected['best_epochs']['base']
            args.kd_epochs=selected['best_epochs']['kd']
            print('Selected',backbone,'epochs:',selected['best_epochs'])
        common=dict(dataset=args.dataset,backbone=backbone,stage=args.stage,
                    data_root=args.data_root,output=args.output,outer_fold=args.outer_fold,
                    seed=args.seed,device=args.device,lr=args.lr,batch_size=args.batch_size,
                    temperature=args.temperature,hard=args.hard,soft=args.soft,feature=args.feature)
        if args.split=='final':
            run_final(**common,teacher_epochs=args.teacher_epochs,base_epochs=args.base_epochs,kd_epochs=args.kd_epochs)
        else:
            folds=range(1,6) if args.inner_fold=='all' else [int(args.inner_fold)]
            for i in folds:
                run_inner(**common,inner_fold=i,epochs=args.epochs,patience=args.patience)

if __name__=='__main__':main()
