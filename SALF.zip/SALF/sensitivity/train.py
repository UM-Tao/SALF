import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from SALF.data.grouping import reference_labels, digest

FEATURES_OBA_HBA=['t_IES_1','t_IES_2','t_alpha_1','t_alpha_2','entropy']
FEATURES_VITAL=['first_ies_sec_ch1','first_ies_sec_ch2','first_alphaS_sec_ch1','first_alphaS_sec_ch2','permutation_entropy']

def train(dataset,feature_table,output,columns=None,id_col=None,seed=42,allow_partial=False,
          reference_file=None,label_col=None):
    if dataset not in ('OBA','HBA','VitalDB'):raise ValueError(dataset)
    d,idcol=reference_labels(feature_table,reference_file,id_col,label_col)
    cols=list(columns or (FEATURES_VITAL if dataset=='VitalDB' else FEATURES_OBA_HBA))
    if len(cols)!=5 or len(set(cols))!=5:raise ValueError('Exactly five distinct EEG onset/entropy features needed')
    if any(c not in d.columns for c in cols):raise ValueError(f'Missing feature columns: {set(cols)-set(d.columns)}')
    if any(c.lower() in ('phenotype','sensitivity_label','reference_phenotype','label','target','bis','d_ies_30min') or '30min' in c.lower() for c in cols):
        raise ValueError('Label leakage risk: 30-min reference, BIS, or phenotype used as feature')
    X=d[cols].apply(pd.to_numeric,errors='coerce').to_numpy(dtype=float)
    X[~np.isfinite(X)]=np.nan
    if np.isnan(X).all(axis=0).any():raise ValueError('An entire feature column is missing')
    if dataset=='VitalDB':
        for i in range(4):X[:,i]=np.nan_to_num(X[:,i],nan=600.,posinf=600.,neginf=0.).clip(0,600)
    y=(d._reference=='S').astype(int).to_numpy()
    if len(np.unique(y))!=2:raise ValueError('Need both S and NS references')
    ntrees=500 if dataset=='VitalDB' else 1000
    model=Pipeline([('imputer',SimpleImputer(strategy='median')),
         ('rf',RandomForestClassifier(n_estimators=ntrees,max_features='sqrt',class_weight='balanced',random_state=seed+9999,n_jobs=-1))])
    model.fit(X,y)
    root=Path(output);root.mkdir(parents=True,exist_ok=True)
    path=root/f'{dataset}_RF_final.joblib'
    if path.exists():raise FileExistsError(f'RF output already exists: {path}. Use another directory.')
    joblib.dump({'model':model,'features':cols,'dataset':dataset,'id_column':idcol,
                 'reference_labels':'S=1 / NS=0','subjects':d._sid.tolist(),
                 'source_table':str(Path(feature_table).resolve()),
                 'source_sha256':digest(feature_table),'train_label_mode':'reference'},path)
    pd.DataFrame({'feature':cols,'importance':model.named_steps['rf'].feature_importances_}).to_csv(root/'feature_importance.csv',index=False)
    # Clearly labeled in-sample predictions, not held-out validation.
    p_s=model.predict_proba(X)[:,list(model.classes_).index(1)]
    pd.DataFrame({'subject_id':d._sid,'reference_phenotype':d._reference,
                  'fitted_model_prob_S_IN_SAMPLE':p_s}).to_csv(root/'training_subject_predictions_IN_SAMPLE.csv',index=False)
    (root/'run.json').write_text(json.dumps({'dataset':dataset,'S':int(y.sum()),'NS':int((1-y).sum()),
      'subject_count':len(y),'feature_table':str(Path(feature_table).resolve()),'features':cols,
      'rf_trees':ntrees,'seed':seed,'fit':'FINAL FIT ONLY; saved in-sample scores are NOT out-of-fold evaluation; reference labels required',
      'feature_count':len(cols)},indent=2,ensure_ascii=False),encoding='utf-8')
    print('Saved RF',path,flush=True)
    return path
