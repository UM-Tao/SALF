# Canonical labels: 0 Awake, 1 Optimal, 2 Excessive.


import hashlib, json, shutil
from pathlib import Path
import numpy as np

CLASS_NAMES = {0:'Awake',1:'Optimal',2:'Excessive'}
SCHEMA_ID = 'AWAKE_OPTIMAL_EXCESSIVE_V1'
REVERSED_NAMES = {0:'Excessive',1:'Optimal',2:'Awake'}

def mapping_from_order(order):
    if order=='canonical': return {0:0,1:1,2:2}
    if order=='reversed': return {0:2,1:1,2:0}
    raise ValueError(f'Unknown class order {order!r}')

def convert_labels(labels, order):
    arr=np.asarray(labels)
    if not np.issubdtype(arr.dtype,np.integer) or not set(np.unique(arr)).issubset({0,1,2}):
        raise ValueError('Expected integer DoA labels 0, 1 or 2 only')
    mapping=mapping_from_order(order)
    return np.take(np.asarray([mapping[0],mapping[1],mapping[2]],dtype=np.int64),arr.astype(np.int64))

def write_schema(dataset_dir, *, dataset, input_order='canonical', source='', extra=None):
    root=Path(dataset_dir);root.mkdir(parents=True,exist_ok=True)
    path=root/'label_semantics.json'
    payload={'dataset':dataset,'schema':SCHEMA_ID,'labels':{str(k):v for k,v in CLASS_NAMES.items()},
             'input_order':input_order,'conversion':mapping_from_order(input_order),'source':str(source)}
    if extra:payload.update(extra)
    if path.exists():
        old=json.loads(path.read_text(encoding='utf-8'))
        if old!=payload:raise FileExistsError(f'{path} already exists with DIFFERENT label semantics. Use a new dataset root.')
    else:path.write_text(json.dumps(payload,indent=2,ensure_ascii=False),encoding='utf-8')
    return path

def verify_schema(dataset_dir, files=None):
    root=Path(dataset_dir);p=root/'label_semantics.json'
    if p.exists():
        d=json.loads(p.read_text(encoding='utf-8'))
        if d.get('schema')!=SCHEMA_ID or {str(k):v for k,v in CLASS_NAMES.items()} != d.get('labels'):
            raise ValueError(f'{p}: NOT canonical; use `python -m SALF migrate-labels` to create a different data root.')
        return True
    files=files or list(root.rglob('*.npz'))
    if not files: return True
    for f in files:
        with np.load(f,allow_pickle=False) as z:
            if 'label_schema' not in z or str(z['label_schema'].item())!=SCHEMA_ID:
                raise ValueError(f'{root}: missing canonical label_semantics.json and {f} lacks verified label_schema. '
                                 'Use `python -m SALF label-stamp --dataset ... --data-root ...` ONLY after confirming '+
                                 '0=Awake,1=Optimal,2=Excessive; otherwise use migrate-labels.')
    return True

def stamp(dataset,data_root):
    root=Path(data_root)/dataset
    files=list(root.glob('incoming/*.npz'))+list(root.glob('S/*.npz'))+list(root.glob('NS/*.npz'))
    if not files:raise FileNotFoundError(f'{root}: no incoming/S/NS NPZ to stamp')
    if (root/'label_semantics.json').is_file():
        verify_schema(root,files);print('Already canonical:',root);return
    write_schema(root,dataset=dataset,input_order='canonical',source='user-declared label mapping')
    print('Stamped canonical class mapping; this is an assertion, NOT automated clinical verification:',root)

def migrate(dataset,source_root,output_root,from_order='reversed'):

    src=Path(source_root)/dataset;dst=Path(output_root)/dataset
    if src.resolve()==dst.resolve():raise ValueError('Source and destination roots MUST be different')
    if dst.exists() and any(dst.iterdir()):raise FileExistsError(f'{dst}: destination must be empty; no overwrites')
    targets=[]
    for folder in ('incoming','S','NS','sen','nonsen','nonsense'):
        for f in (src/folder).glob('*.npz'):
            targets.append((f,folder))
    if not targets:raise FileNotFoundError(f'No per-patient NPZ found under {src}/incoming,S,NS')
    copied=[];ledger=[]
    try:
        for f,folder in targets:
            out=dst/folder/f.name;out.parent.mkdir(parents=True,exist_ok=True)
            with np.load(f,allow_pickle=False) as z:
                data={key:z[key] for key in z.files}
            data['y']=convert_labels(data['y'],from_order)
            data['label_schema']=np.array(SCHEMA_ID)
            np.savez_compressed(out,**data);copied.append(out)
            checksum=hashlib.sha256(out.read_bytes()).hexdigest()
            ledger.append({'subject_id':f.stem,'group_folder':folder,'original_path':str(f),
                           'new_path':str(out),'sha256':checksum,'original_order':from_order})
        write_schema(dst,dataset=dataset,input_order=from_order,source=str(src),extra={'migrated':True})
        import pandas as pd
        pd.DataFrame(ledger).to_csv(dst/'label_migration_manifest.csv',index=False)

        if all((dst/f).is_dir() for f in ('S','NS')):
            rec=[{'subject_id':p.stem,'phenotype':grp,'file':p.relative_to(dst).as_posix(),'source':'migrated:'+from_order}
                 for grp in ('S','NS') for p in sorted((dst/grp).glob('*.npz'))]
            pd.DataFrame(rec).to_csv(dst/'subjects.csv',index=False)
        print('Migrated',len(copied),'files to',dst)
    except Exception:
        if dst.exists():shutil.rmtree(dst)
        raise
