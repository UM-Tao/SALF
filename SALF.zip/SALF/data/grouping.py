from __future__ import annotations
import hashlib
import json
import os
import shutil
import tempfile
from pathlib import Path
from SALF.data.labels import verify_schema

import joblib
import numpy as np
import pandas as pd

DATASETS = ('OBA','HBA','VitalDB')
FOLDER_ALIASES = {'S':('S','sen','sensitive'), 'NS':('NS','nonsen','nonsense','non_sensitive','non-sensitive')}
ID_CANDIDATES = ('subject_id','pid','PID','patient_id','caseid','case_id','subject','id')
REFERENCE_CANDIDATES = ('reference_phenotype','phenotype','sensitivity_label','reference_label','group')


def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as fp:
        for chunk in iter(lambda:fp.read(2**20), b''):h.update(chunk)
    return h.hexdigest()


def clean_id(value):
    val=str(value).strip()
    if val.endswith('.0') and val[:-2].isdigit():val=val[:-2]
    if not val or val in ('.','..') or '/' in val or '\\' in val:raise ValueError(f'Invalid subject_id {value!r}')
    return val


def normalize_group(value):
    v=str(value).strip().lower().replace('_','').replace('-','').replace(' ','')
    if v in ('s','sen','sensitive','1','true'):return 'S'
    if v in ('ns','nonsen','nonsense','nonsensitive','0','false'):return 'NS'
    raise ValueError(f'Unknown phenotype {value!r}')


def _read_table(filename):
    p=Path(filename)
    if not p.is_file():raise FileNotFoundError(p)
    if p.suffix.lower() in ('.xlsx','.xls'):return pd.read_excel(p,dtype=str)
    return pd.read_csv(p,dtype=str)


def resolve_group_folders(dataset_dir):
    root=Path(dataset_dir)
    folders={}
    for group,aliases in FOLDER_ALIASES.items():
        options=[root/a for a in aliases if (root/a).is_dir()]
        if len(options)>1:raise ValueError(f'{root}: multiple folders for {group}: {options}; keep only one alias')
        if not options:raise FileNotFoundError(f'{root}: missing {group}/ folder (also recognizes {aliases})')
        folders[group]=options[0]
    return folders


def _npz_subject(path):

    return clean_id(path.stem)


def scan_grouped(data_root,dataset,validate_manifest=True):
    if dataset not in DATASETS:raise ValueError(dataset)
    root=Path(data_root)/dataset
    verify_schema(root)
    folders=resolve_group_folders(root)
    recs=[];ids=set()
    for group in ('S','NS'):
        folder=folders[group]
        direct=sorted(folder.glob('*.npz'))
        nested=[p for p in folder.rglob('*.npz') if p.parent!=folder]
        if nested:raise ValueError(f'{folder}: per-subject NPZ must be directly inside S/ or NS/; unexpected nested {nested[:4]}')
        for path in direct:
            sid=_npz_subject(path)
            if sid in ids:raise ValueError(f'{dataset}: duplicate subject {sid} across S/NS')
            ids.add(sid)
            recs.append({'subject_id':sid,'phenotype':group,'file':path.relative_to(root).as_posix(),
                         'source':f'folder:{path.parent.name}'})
    if not recs:raise ValueError(f'{root}: no NPZ files in S/ or NS/')
    df=pd.DataFrame(recs).sort_values(['phenotype','subject_id']).reset_index(drop=True)
    if not set(df.phenotype)=={'S','NS'}:raise ValueError(f'{root}: both S and NS required')
    old=root/'subjects.csv'
    if old.is_file() and validate_manifest:
        expected=pd.read_csv(old,dtype=str).fillna('')
        needed=['subject_id','phenotype','file']
        if not set(needed)<=set(expected):raise ValueError(f'{old}: missing {set(needed)-set(expected)}')
        a=expected[needed].sort_values(needed).reset_index(drop=True)
        b=df[needed].sort_values(needed).reset_index(drop=True)
        if not a.equals(b):raise ValueError(f'{old} is stale for folder contents. Run `python -m SALF scan --dataset {dataset} --data-root ... --refresh`, or use another data/output directory.')
    return df


def save_scan(data_root,dataset,refresh=False):
    root=Path(data_root)/dataset

    old=root/'subjects.csv'
    df=scan_grouped(data_root,dataset,validate_manifest=not refresh)
    if refresh or not old.is_file():df.to_csv(old,index=False)
    manifest=[]
    for r in df.itertuples(index=False):
        path=root/r.file
        manifest.append({'subject_id':r.subject_id,'phenotype':r.phenotype,'file':r.file,'sha256':digest(path)})
    pd.DataFrame(manifest).to_csv(root/'subject_file_manifest.csv',index=False)
    print(f'{dataset}: S={sum(df.phenotype=="S")}, NS={sum(df.phenotype=="NS")}; saved {old}',flush=True)
    return df


def reference_labels(table,reference_labels=None,id_col=None,label_col=None):
    feature_df=_read_table(table)
    id_col=id_col or next((x for x in ID_CANDIDATES if x in feature_df.columns),None)
    if id_col is None:raise ValueError(f'{table}: missing ID column from {ID_CANDIDATES}')
    feature_df=feature_df.copy()
    feature_df['_sid']=feature_df[id_col].map(clean_id)
    if feature_df._sid.duplicated().any():raise ValueError('Feature table has duplicate subject IDs')
    if reference_labels:
        labels=_read_table(reference_labels)
        label_id=next((x for x in ID_CANDIDATES if x in labels.columns),None)
        label_col=label_col or next((x for x in REFERENCE_CANDIDATES if x in labels.columns),None)
        if label_id is None or label_col is None:raise ValueError('Reference label file needs subject ID and phenotype')
        labels=labels[[label_id,label_col]].copy()
        labels['_sid']=labels[label_id].map(clean_id)
        if labels._sid.duplicated().any():raise ValueError('Reference labels contain duplicate IDs')
        labels=labels[['_sid',label_col]].rename(columns={label_col:'_reference_raw'})
        feature_df=feature_df.merge(labels,on='_sid',how='left',validate='one_to_one')
        if feature_df._reference_raw.isna().any():raise ValueError('Missing reference labels for feature subjects')
        feature_df['_reference']=feature_df['_reference_raw'].map(normalize_group)
    else:
        label_col=label_col or next((x for x in REFERENCE_CANDIDATES if x in feature_df.columns),None)
        if label_col is None:raise ValueError('For RF training/reference grouping provide phenotype/\nreference_phenotype/sensitivity_label or --reference-labels CSV')
        feature_df['_reference']=feature_df[label_col].map(normalize_group)
    return feature_df,id_col


def _unassigned_files(dataset_dir):
    root=Path(dataset_dir)
    inbox=root/'incoming'

    files=sorted(inbox.glob('*.npz')) if inbox.is_dir() else sorted(root.glob('*.npz'))
    if not files:raise FileNotFoundError(f'{root}: expected incoming/<subject_id>.npz, or existing S/ and NS/ directories')
    if any(p.is_dir() for p in files):raise ValueError('unexpected directory')
    ids=[_npz_subject(p) for p in files]
    if len(set(ids))!=len(ids):raise ValueError(f'Duplicate IDs in incoming {root}')
    return list(zip(ids,files))


def assign_groups(*,dataset,data_root,feature_table,assignment='reference',rf_model=None,
                  reference_file=None,id_col=None,label_col=None,allow_training_subject_predictions=False):


    if dataset not in DATASETS:raise ValueError(dataset)
    if assignment not in ('reference','predicted'):raise ValueError(assignment)
    root=Path(data_root)/dataset
    verify_schema(root)
    sources=_unassigned_files(root)
    fdf,_=reference_labels(feature_table,reference_file,id_col,label_col) if (reference_file or assignment=='reference') else (_read_table(feature_table),None)
    if '_sid' not in fdf:
        id_col=id_col or next((x for x in ID_CANDIDATES if x in fdf.columns),None)
        if not id_col:raise ValueError('No subject ID column in feature table')
        fdf=fdf.copy();fdf['_sid']=fdf[id_col].map(clean_id)
        if fdf._sid.duplicated().any():raise ValueError('Duplicate subjects in feature table')
    fdf=fdf.set_index('_sid',drop=False)
    absent=[sid for sid,p in sources if sid not in fdf.index]
    if absent:raise ValueError(f'Missing early features/labels for incoming subject IDs {absent[:10]}')
    model_sha=''
    in_sample=[]
    if assignment=='predicted':
        if not rf_model:raise ValueError('--rf-model required with --assignment predicted')
        saved=joblib.load(rf_model)
        if saved.get('dataset')!=dataset:raise ValueError('RF model dataset differs')
        cols=saved['features']
        if any(c not in fdf.columns for c in cols):raise ValueError(f'Missing RF input columns {set(cols)-set(fdf.columns)}')
        rf=saved['model']
        model_sha=digest(rf_model)
        training=set(map(str,saved.get('subjects',[])))
        in_sample=sorted({sid for sid,_ in sources}&training)
        if in_sample and not allow_training_subject_predictions:
            raise ValueError(f'RF was fitted on {len(in_sample)} of the same subjects; predicted groups would be in-sample. Provide independent or OOF RF predictions, or explicitly --allow-training-subject-predictions for an exploratory run.')
        features=fdf.loc[[sid for sid,_ in sources],cols].apply(pd.to_numeric,errors='coerce').to_numpy(dtype=float)
        features[~np.isfinite(features)]=np.nan
        prob=rf.predict_proba(features)
        classes=list(rf.classes_)
        class_s=classes.index(1)
        p_s=prob[:,class_s]
        predictions={sid:('S' if p>=.5 else 'NS',float(p)) for (sid,_),p in zip(sources,p_s)}
    else:
        predictions={sid:(fdf.at[sid,'_reference'],float('nan')) for sid,_ in sources}

    group_values=[item[0] for item in predictions.values()]
    if not {"S","NS"}.issubset(set(group_values)):
        raise ValueError("RF/reference assignment created only one phenotype. No files copied; check source labels/model before DoA training.")

    if (root/'subjects.csv').exists():raise FileExistsError(f'{root}/subjects.csv exists; use another data root for regrouping')
    if (root/'group_assignment_manifest.csv').exists():raise FileExistsError('Existing assignment manifest; use new root')
    destinations=[]
    for sid,source in sources:
        group,p=predictions[sid]
        dest=root/group/f'{sid}.npz'
        if dest.exists():raise FileExistsError(f'Will not overwrite existing grouped subject: {dest}')
        destinations.append((sid,source,dest,group,p))
    for group in ('S','NS'):
        folder=root/group
        if folder.is_dir() and list(folder.glob('*.npz')):
            raise FileExistsError(f'Nonempty {folder}; refusing partial regrouping. Use a new data root.')
    records=[];copies=[]
    try:
        for sid,source,dest,group,ps in destinations:
            dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(source,dest);copies.append(dest)
            src_hash=digest(source);dst_hash=digest(dest)
            if src_hash!=dst_hash:raise IOError(f'Copy mismatch {source} -> {dest}')
            records.append({'subject_id':sid,'phenotype':group,'file':dest.relative_to(root).as_posix(),
                            'source':f'{assignment}:{Path(feature_table).name}',
                            'source_file':str(source.resolve()),'source_sha256':src_hash,
                            'copy_sha256':dst_hash,'assignment_mode':assignment,
                            'prob_sensitive':ps,'rf_model_sha256':model_sha})
        df=pd.DataFrame(records).sort_values(['phenotype','subject_id'])
        df[['subject_id','phenotype','file','source']].to_csv(root/'subjects.csv',index=False)
        df.to_csv(root/'group_assignment_manifest.csv',index=False)
        (root/'group_assignment.json').write_text(json.dumps({'dataset':dataset,'assignment_mode':assignment,
            'reference_provenance':str(reference_file or feature_table) if assignment=='reference' else 'RF_prediction',
            'rf_model':str(rf_model or ''),'rf_model_sha256':model_sha,
            'rf_training_subject_overlap':in_sample,
            'assignment_description':'Groups assigned by sensitivity RF predictions' if assignment=='predicted' else 'Groups assigned by supplied sensitivity labels'},indent=2,ensure_ascii=False),encoding='utf-8')
        print(f'{dataset}: grouped S={(df.phenotype=="S").sum()} NS={(df.phenotype=="NS").sum()} to {root}',flush=True)
        return df
    except Exception:
        for p in copies:
            if p.is_file():p.unlink()
        raise
