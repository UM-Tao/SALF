import io,re,zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from SALF.data.io import write_json,sha
from SALF.data.labels import convert_labels,write_schema,SCHEMA_ID

def prepare_oba_zip(source,output,step=1,source_order='canonical'):

 source=Path(source);root=Path(output)/'OBA';inbox=root/'incoming'
 if inbox.exists() and list(inbox.glob('*.npz')):raise FileExistsError(f'{inbox} already contains files')
 inbox.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(source) as z:
  psd={}; lab={}
  for path in z.namelist():
   name=Path(path).name
   m=re.fullmatch(r'psdata_(.+)\.txt',name,re.IGNORECASE)
   n=re.fullmatch(r'label_(.+)\.txt',name,re.IGNORECASE)
   if m:
    sid=m.group(1)
    if sid in psd:raise ValueError(f'Ambiguous OBA PSD file for subject {sid}')
    psd[sid]=path
   if n:
    sid=n.group(1)
    if sid in lab:raise ValueError(f'Ambiguous OBA label file for subject {sid}')
    lab[sid]=path
  if set(psd)!=set(lab) or not psd:raise ValueError(f'Unpaired OBA PSD/label subjects: PSD only {set(psd)-set(lab)}, labels only {set(lab)-set(psd)}')
  stats=[]
  for sid in sorted(psd):
   X=np.loadtxt(io.BytesIO(z.read(psd[sid])),dtype=np.float32,ndmin=2,delimiter=',')
   y=np.loadtxt(io.BytesIO(z.read(lab[sid])),dtype=np.float64,ndmin=1).reshape(-1)
   if len(y)!=len(X) or X.shape[1]!=40:raise ValueError(f'OBA {sid}: expected same rows and 40 PSD features')
   ends=np.arange(19,len(y),step)
   valid_rows=np.isfinite(X).all(axis=1)
   bad=np.cumsum(np.r_[0,(~valid_rows).astype(int)])
   ends=ends[(bad[ends+1]-bad[ends-19]==0)&np.isfinite(y[ends])]
   if not len(ends) or not np.all(np.isin(y[ends],[0.,1.,2.])):raise ValueError(f'OBA {sid}: no valid 20-row sequences or invalid class labels')
   chunks=np.lib.stride_tricks.sliding_window_view(X,20,axis=0).transpose(0,2,1)
   ids=[f'OBA:{sid}:psdend:{e}' for e in ends]
   np.savez_compressed(inbox/f'{sid}.npz',x_psd=chunks[ends-19].copy(),y=convert_labels(y[ends].astype('int64'),source_order),case_ids=np.asarray(ids),window_start=(ends-19).astype('int64'),window_end=ends.astype('int64'),label_schema=np.array(SCHEMA_ID))
   stats.append({'subject_id':sid,'n_sequences':len(ends),'source_psd':psd[sid],'source_label':lab[sid]})
 write_schema(root,dataset='OBA',input_order=source_order,source=str(source))
 pd.DataFrame(stats).to_csv(root/'preparation_manifest.csv',index=False)
 write_json(root/'source_audit.json',{'zip_sha256':sha(source),'source':str(source),'psd_window':20,'stride_rows':step,'target':'last PSD row','source_label_order':source_order,'canonical_labels':{'0':'Awake','1':'Optimal','2':'Excessive'},'sensitivity_assignment':'NOT DONE. Use `python -m SALF group` or pre-existing S/NS folders.','time_alignment':'Uses input PSD row indices'})
 return inbox
