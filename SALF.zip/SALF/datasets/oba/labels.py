from SALF.data.labels import CLASS_NAMES, convert_labels
DATASET='OBA'
SOURCE_RASS_MAPPING='Inherited labels from source psdata/label TXT; review original clinical RASS mapping'
