# Labels: 0 Awake; unconscious rows split at the subject-specific alpha median.

from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from SALF.datasets.common import _windows
from SALF.data.io import write_json
from SALF.data.labels import write_schema,SCHEMA_ID

def _digest(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):
            h.update(b)
    return h.hexdigest()


def _check_output(out):
    if out.exists() and list(out.glob('*.npz')):
        raise FileExistsError(f'{out}: has prepared NPZ; use another data root')
    out.mkdir(parents=True, exist_ok=True)


def _load_hba_subject(folder,pid,strict_lengths=True):
    f=folder/f'{pid}_Sdb.csv'; g=folder/f'{pid}_l.csv'
    if not f.is_file() or not g.is_file():
        raise FileNotFoundError(f'HBA subject {pid}: expected {f.name} and {g.name}')
    vals=pd.read_csv(f,header=None).to_numpy()

    vals=vals if vals.shape[0]>vals.shape[1] else vals.T
    if vals.ndim!=2 or vals.shape[1]<40:
        raise ValueError(f'HBA subject {pid}: {f} unexpected shape {vals.shape}')
    original_labels=pd.read_csv(g,header=None).to_numpy().reshape(-1)
    if len(vals)!=len(original_labels):
        if strict_lengths:
            raise ValueError(f'HBA subject {pid}: spectra={len(vals)} != l.csv={len(original_labels)}; Use --allow-length-trim if the row alignment is verified.')
        n=min(len(vals),len(original_labels));vals=vals[:n];original_labels=original_labels[:n]

    # Unknown is NOT a valid negative/positive label and must never be cast to int.
    valid=np.isfinite(original_labels)
    if not np.isin(original_labels[valid],[0,1]).all():
        unexpected=np.unique(original_labels[valid][~np.isin(original_labels[valid],[0,1])])
        raise ValueError(f'HBA subject {pid}: unexpected finite labels: {unexpected}')
    if not valid.any():raise ValueError(f'HBA subject {pid}: no labeled rows')
    # Standardize all spectral rows within each subject for label derivation.
    # The model input normalization is handled separately.
    raw=np.nan_to_num(vals[:,:40].astype(np.float32),nan=0.0,posinf=0.0,neginf=0.0)
    std=StandardScaler().fit_transform(raw)
    score=np.mean(std[:,16:24],axis=1)
    unconscious=(original_labels==0)
    if not unconscious.any():raise ValueError(f'HBA subject {pid}: no valid unconscious rows for median')
    median=float(np.median(score[unconscious]))
    original_indices=np.flatnonzero(valid).astype(np.int64)
    orig=original_labels[valid].astype(np.int64)
    y=np.where(orig==1,0,np.where(score[valid]>=median,1,2)).astype(np.int64)
    metadata={'sdb_sha256':_digest(f),'label_sha256':_digest(g),
              'spectral_columns':int(vals.shape[1]),
              'n_total_rows':int(len(original_labels)),
              'n_missing_annotation_rows':int((~valid).sum()),
              'n_valid_annotation_rows':int(valid.sum())}
    return raw[valid],y,orig,score[valid],median,metadata,original_indices


def export_hba(hba_source,data_root,stride=1,allow_length_trim=False):
    hba_source=Path(hba_source)
    root=Path(data_root)/'HBA';dest=root/'incoming';_check_output(dest)
    files=sorted(hba_source.glob('*_Sdb.csv'))
    if not files:raise FileNotFoundError(f'No <subject>_Sdb.csv in {hba_source}')
    ids=[p.name[:-len('_Sdb.csv')] for p in files]
    absent=[str(hba_source/f'{sid}_l.csv') for sid in ids if not (hba_source/f'{sid}_l.csv').exists()]
    if absent:raise FileNotFoundError(f'Missing matching labels: {absent[:8]}')
    labels=[];summary=[]
    for sid in ids:
        x,y,orig,score,med,src,row_idx=_load_hba_subject(hba_source,sid,not allow_length_trim)
        seq,ends=_windows(x,y,row_idx,f'HBA:{sid}',stride=stride)
        seq['label_schema']=np.array(SCHEMA_ID)
        np.savez_compressed(dest/f'{sid}.npz',**seq)
        summary.append(dict(subject_id=sid,n_source=len(y),n_sequences=len(ends),label0=int((y==0).sum()),label1=int((y==1).sum()),label2=int((y==2).sum()),median=med,**src))
        labels.extend(dict(subject_id=sid,original_row=int(row_idx[i]),original_state=int(orig[i]),alpha_score=float(score[i]),subject_median=med,label=int(y[i])) for i in range(len(y)))
    pd.DataFrame(labels).to_csv(root/'HBA_three_class_labels.csv',index=False)
    pd.DataFrame(summary).to_csv(root/'source_audit.csv',index=False)
    write_json(root/'dataset_label_rules.json',{
        'source':'HBA spectral CSV and consciousness annotations; unknown labels excluded',
        'labels':{'0':'Awake','1':'Optimal','2':'Excessive'},
        'alpha_score':'Per-subject StandardScaler over all spectral rows; mean standardized columns 16:24; unconscious-row median threshold',
        'stride':int(stride)})
    write_schema(root,dataset='HBA',source=str(hba_source),extra={'alpha_recipe':'Per-subject StandardScaler over all spectral rows; mean columns 16:24; median of unconscious rows'})
    return {'subjects':len(ids),'sequences':int(sum(x['n_sequences'] for x in summary)),'destination':str(dest)}

