from SALF.data.labels import CLASS_NAMES,convert_labels
DATASET='VitalDB'
BIS_RULES={'Awake':'BIS > 60','Optimal':'40 <= BIS <= 60','Excessive':'BIS < 40'}
