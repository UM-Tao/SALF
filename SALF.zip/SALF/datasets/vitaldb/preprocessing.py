from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
from SALF.datasets.common import _windows
from SALF.data.io import write_json
from SALF.data.labels import convert_labels,write_schema,SCHEMA_ID

def _digest(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):
            h.update(b)
    return h.hexdigest()


def _check_output(out):
    if out.exists() and list(out.glob('*.npz')):
        raise FileExistsError(f'{out}: has prepared NPZ; use another data root')
    out.mkdir(parents=True, exist_ok=True)


def _phen_label(value):
    v=str(value).strip().lower().replace('-','_').replace(' ','_')
    if v in ('s','sen','sensitive'):return 'S'
    if v in ('ns','nonsen','non_sensitive','nonsensitive'):return 'NS'
    raise ValueError(f'Unknown VitalDB phenotype value {value!r}; expected sensitive/non_sensitive')


def export_vitaldb(selected_csv,cache_dir,data_root,stride=1,cache_order='reversed'):

    sel=Path(selected_csv);cache_dir=Path(cache_dir)
    if not sel.is_file():raise FileNotFoundError(sel)
    d=pd.read_excel(sel) if sel.suffix.lower() in ('.xlsx','.xls') else pd.read_csv(sel)
    col=next((x for x in ('caseid','case_id','subject_id') if x in d.columns),None)
    if col is None:raise ValueError('VitalDB selection CSV needs caseid/case_id/subject_id')
    if d[col].isna().any() or d[col].astype(str).duplicated().any() or not len(d):raise ValueError('Nonempty unique IDs required')
    d=d.copy();d['_id']=d[col].astype(str).str.replace(r'\.0$','',regex=True)
    missing=[sid for sid in d['_id'] if not (cache_dir/f'{sid}.npz').is_file()]
    if missing:raise FileNotFoundError(f'Missing cached NPZ: {missing[:12]}')
    root=Path(data_root)/'VitalDB';dest=root/'incoming';_check_output(dest)
    audit=[];window_rows=[]
    for sid in d['_id']:
        fn=cache_dir/f'{sid}.npz'
        with np.load(fn,allow_pickle=False) as z:
            for key in ('features','labels','window_idx'):
                if key not in z:raise ValueError(f'{fn}: missing {key}')
            x=np.asarray(z['features'],np.float32);y=convert_labels(np.asarray(z['labels'],np.int64),cache_order);idx=np.asarray(z['window_idx'],np.int64)
        seq,ends=_windows(x,y,idx,f'VitalDB:{sid}',stride=stride)
        seq['window_start']=(seq['window_start']*2).astype(np.int64)
        seq['window_end']=(seq['window_end']*2).astype(np.int64)
        seq['label_schema']=np.array(SCHEMA_ID)
        np.savez_compressed(dest/f'{sid}.npz',**seq)
        audit.append(dict(subject_id=sid,n_source=len(y),n_sequences=len(ends),n0=int((y==0).sum()),n1=int((y==1).sum()),n2=int((y==2).sum()),cache_sha256=_digest(fn)))
        window_rows.extend(dict(subject_id=sid,window_idx=int(idx[e]),label=int(y[e]),seq_start_window=int(idx[e]-19),seq_end_window=int(idx[e])) for e in ends)
    d.drop(columns='_id').to_csv(root/'selected_cases.csv',index=False)
    pd.DataFrame(audit).to_csv(root/'source_audit.csv',index=False)
    pd.DataFrame(window_rows).to_csv(root/'VitalDB_window_manifest.csv',index=False)
    write_json(root/'dataset_label_rules.json',{'labels':{'0':'Awake/Light (BIS>60)','1':'Optimal (40<=BIS<=60)','2':'Excessive/Deep (BIS<40)'},
        'source':'VitalDB cached 2-second, 40-feature EEG windows',
        'selection':'Case IDs listed in selected_cases.csv',
        'assignment':'No sensitivity phenotype assigned until group command.',
        'stride':int(stride)})
    write_schema(root,dataset='VitalDB',input_order=cache_order,source=str(cache_dir))
    return {'subjects':len(d),'sequences':int(sum(x['n_sequences'] for x in audit)),'destination':str(dest)}
