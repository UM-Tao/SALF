import numpy as np

def _windows(feat, lab, row_idx, prefix, *, stride=1):


    x=np.asarray(feat,dtype=np.float32)
    y=np.asarray(lab,dtype=np.int64)
    idx=np.asarray(row_idx,dtype=np.int64)
    if x.ndim!=2 or x.shape[1]!=40 or len(y)!=len(x) or len(idx)!=len(x):
        raise ValueError(f'{prefix}: expected [N,40] x, [N] labels and [N] indices')
    if not np.all(np.isfinite(x)) or not np.all(np.isin(y,[0,1,2])):
        raise ValueError(f'{prefix}: invalid PSD or label values')
    if len(idx)>1 and not np.all(np.diff(idx)>0):
        raise ValueError(f'{prefix}: original index not strictly increasing')
    stride=int(stride)
    if stride<1:raise ValueError('stride must be >= 1')
    if len(x)<20:raise ValueError(f'{prefix}: fewer than 20 original rows')

    ends=np.arange(19,len(x),stride)
    bad=np.cumsum(np.r_[0,(np.diff(idx)!=1).astype(np.int64)])
    ends=ends[(bad[ends]-bad[ends-19])==0]
    if not len(ends):raise ValueError(f'{prefix}: no contiguous 20-window sequences')
    view=np.lib.stride_tricks.sliding_window_view(x,20,axis=0).transpose(0,2,1)
    xx=view[ends-19].astype(np.float32,copy=True)
    yy=y[ends].copy()
    end_original=idx[ends]
    ids=np.asarray([f'{prefix}:winend:{v}' for v in end_original],dtype=str)
    return dict(x_psd=xx,y=yy,case_ids=ids,
                window_start=(idx[ends]-19).astype(np.int64),
                window_end=(idx[ends]+1).astype(np.int64)), ends


