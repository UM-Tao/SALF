import math
import torch
from torch import nn
from .common import AttnLayer
class PositionalEncoding(nn.Module):
    def __init__(self,d_model,max_len=1000):
        super().__init__(); self.dropout=nn.Dropout(0.5)
        pe=torch.zeros(max_len,d_model); pos=torch.arange(0,max_len,dtype=torch.float).unsqueeze(1)
        div=torch.exp(torch.arange(0,d_model,2).float()*(-math.log(10000.0)/d_model))
        pe[:,0::2]=torch.sin(pos*div); pe[:,1::2]=torch.cos(pos*div); self.register_buffer('pe',pe.unsqueeze(0))
    def forward(self,x): return x+self.pe[:,:x.size(1)]

class TransformerEncoder(nn.Module):
    def __init__(self,n_heads=8,embed_dim=128,n_layers=3,normalization='batch',feed_forward_hidden=512):
        super().__init__(); self.layers=nn.Sequential(*[AttnLayer(n_heads,embed_dim,feed_forward_hidden,normalization) for _ in range(n_layers)])
    def forward(self,x): return self.layers(x)

class TransformerClassifier(nn.Module):
    def __init__(self,input_dim=40,embedding_dim=128,n_heads=8,n_layers=3,seq_len=20,output_size=3,feed_forward_hidden=512):
        super().__init__(); self.seq_len=seq_len
        self.init_embed=nn.Linear(input_dim,embedding_dim); self.pos=PositionalEncoding(embedding_dim)
        self.encoder=TransformerEncoder(n_heads,embedding_dim,n_layers,'batch',feed_forward_hidden)
        self.decoder_1=nn.Linear(embedding_dim*seq_len,input_dim); self.decoder_2=nn.Linear(input_dim,output_size)
    def forward(self,x,return_mid=False):
        z=self.encoder(self.pos(self.init_embed(x)))
        if z.size(1)!=self.seq_len: raise ValueError(f'Transformer seq_len={z.size(1)}, expected={self.seq_len}')
        mid=self.decoder_1(z.contiguous().view(z.size(0),-1)); logits=self.decoder_2(mid)
        return (logits,mid) if return_mid else logits

class SALFSourceTransformer(nn.Module):
    def __init__(self):
        super().__init__();self.net=TransformerClassifier(40,128,8,3,20,3,512)
    def forward(self,x,raw=None):return self.net(x,return_mid=True)
