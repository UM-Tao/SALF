from .lstm import SALFSourceLSTM
from .graph import SALFSourceGraph
from .transformer import SALFSourceTransformer
from .vaal import SALFSourceVAAL

SALF_NAMES = ('SALF_transformer','SALF_lstm','SALF_graph','SALF_vaal')
FACTORIES = {'SALF_transformer':SALFSourceTransformer, 'SALF_lstm':SALFSourceLSTM,
             'SALF_graph':SALFSourceGraph, 'SALF_vaal':SALFSourceVAAL}
def create(name,kind='spectral'):
    if name not in FACTORIES: raise ValueError(name)
    return FACTORIES[name]()
