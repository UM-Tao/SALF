import torch
from torch import nn
from .common import *
class LSTMClassifier(nn.Module):
    def __init__(self,input_size=40,hidden_size=256,output_size=3,num_layers=2,seq_len=20):
        super().__init__(); self.seq_len=seq_len
        self.lstm=nn.LSTM(input_size,hidden_size,num_layers,batch_first=True)
        self.fc1=nn.Linear(hidden_size*seq_len,hidden_size)
        self.relu=nn.ReLU(); self.dropout=nn.Dropout(0.1); self.fc2=nn.Linear(hidden_size,output_size)
    def forward(self,x,return_mid=False):
        h,_=self.lstm(x); b,s,d=h.shape
        if s!=self.seq_len: raise ValueError(f'LSTM seq_len={s}, expected={self.seq_len}')
        mid=self.relu(self.fc1(h.contiguous().view(b,s*d)))
        logits=self.fc2(self.dropout(mid))
        return (logits,mid) if return_mid else logits

class SALFSourceLSTM(nn.Module):
    def __init__(self):
        super().__init__();self.net=LSTMClassifier(40,256,3,2,20)
    def forward(self,x,raw=None):return self.net(x,return_mid=True)
