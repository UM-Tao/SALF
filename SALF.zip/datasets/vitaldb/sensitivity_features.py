"""Optional BIS two-channel VitalDB early-feature extraction from 07 original.
Contains exact perm_entropy/read_vital algorithms; clinical mapping must be verified.
"""
from pathlib import Path
import math
import numpy as np
import pandas as pd
from scipy import signal
FS=128.0
EEG1='BIS/EEG1_WAV';EEG2='BIS/EEG2_WAV'
def read_vital(path, tracks, interval):
    import vitaldb
    vf=vitaldb.VitalFile(str(path))
    arr=vf.to_numpy(tracks,interval=interval)
    if isinstance(arr,tuple):arr=arr[0]
    return np.asarray(arr)

def perm_entropy(x, order=3, delay=1):
    x=np.asarray(x,float)
    x=x[np.isfinite(x)]
    if len(x)<100:return np.nan

    # Downsample after anti-aliasing to reduce unnecessary repeated patterns.
    target_fs=16.0
    q=max(1,int(round(FS/target_fs)))
    if q>1:
        x=signal.decimate(x,q,ftype="fir",zero_phase=True)
    n=len(x)-(order-1)*delay
    if n<=0:return np.nan

    patterns={}
    for i in range(n):
        v=x[i:i+order*delay:delay]
        key=tuple(np.argsort(v,kind="mergesort"))
        patterns[key]=patterns.get(key,0)+1
    p=np.asarray(list(patterns.values()),float)
    p/=p.sum()
    h=-np.sum(p*np.log(p+1e-15))
    return float(h/np.log(math.factorial(order)))

def extract(cohort_root,output,cases=None):
    import vitaldb
    cohort_root=Path(cohort_root);output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    candidates=([Path(cases)] if cases else [cohort_root/n for n in ('selected_cases.csv','selected_cases.xlsx','selected_100.xlsx','selected_100.csv')])
    table=next((p for p in candidates if p.is_file()),None)
    if table is None:raise FileNotFoundError(f'Need selection table, supply --cases; searched: {candidates}')
    d=pd.read_excel(table) if table.suffix.lower() in ('.xlsx','.xls') else pd.read_csv(table)
    timing=['first_ies_sec_ch1','first_ies_sec_ch2','first_alphaS_sec_ch1','first_alphaS_sec_ch2']
    if not {'caseid',*timing}.issubset(d.columns):
        raise ValueError(f'{table} missing caseid or four timing columns; phenotype label can be supplied separately')
    ents=[]
    for row in d.itertuples(index=False):
        cid=int(row.caseid)
        arr=read_vital(cohort_root/'selected_vital'/f'{cid}.vital',[EEG1,EEG2],1/FS)
        start=float(getattr(row,'anestart',0) or 0)
        if not np.isfinite(start):start=0.0
        idx=max(0,int(round(start*FS)))
        raw=np.nanmean(arr[idx:idx+int(600*FS),:2],axis=1)
        ents.append(perm_entropy(raw))
    d['permutation_entropy']=ents
    keep=['caseid']+(['sensitivity_label'] if 'sensitivity_label' in d else [])+timing+['permutation_entropy']
    d[keep].to_csv(output,index=False)
    print('Saved VitalDB early features',output)
