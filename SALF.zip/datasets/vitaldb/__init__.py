"""VITALDB dataset-specific input processing."""
