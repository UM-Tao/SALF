"""VitalDB BIS surrogate DoA label IDs, canonical 0 Awake (>60), 1 Optimal (40..60), 2 Excessive (<40).
Existing VitalDB 40-dim feature caches may have legacy reversed IDs; --cache-label-order selects this explicitly.
"""
from SALF.data.labels import CLASS_NAMES,convert_labels
DATASET='VitalDB'
BIS_RULES={'Awake':'BIS > 60','Optimal':'40 <= BIS <= 60','Excessive':'BIS < 40'}
