"""HBA final 3-class numerical convention 0 Awake / 1 Optimal / 2 Excessive.
Awake from original conscious==1; unconscious alpha-score >= subject median -> Optimal.
Alpha-score preprocessing remains historical; not guaranteed manuscript exact.
"""
from SALF.data.labels import CLASS_NAMES
DATASET='HBA'
CLASS_SEMANTICS=CLASS_NAMES
