"""HBA *_Sdb.csv and *_l.csv conversion, including old alpha-score recipe and canonical class IDs."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from SALF.datasets.common import _windows
from SALF.data.io import write_json
from SALF.data.labels import write_schema,SCHEMA_ID

def _digest(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):
            h.update(b)
    return h.hexdigest()


def _check_output(out):
    if out.exists() and list(out.glob('*.npz')):
        raise FileExistsError(f'{out}: has prepared NPZ; use NEW data root')
    out.mkdir(parents=True, exist_ok=True)


def _load_hba_subject(folder,pid,strict_lengths=True):
    f=folder/f'{pid}_Sdb.csv'; g=folder/f'{pid}_l.csv'
    if not f.is_file() or not g.is_file():
        raise FileNotFoundError(f'HBA subject {pid}: expected {f.name} and {g.name}')
    vals=pd.read_csv(f,header=None).to_numpy()
    # Exact orientation from the supplied load_hba_raw_data().
    vals=vals if vals.shape[0]>vals.shape[1] else vals.T
    if vals.ndim!=2 or vals.shape[1]<40:
        raise ValueError(f'HBA subject {pid}: {f} unexpected shape {vals.shape}')
    original_labels=pd.read_csv(g,header=None).to_numpy().reshape(-1)
    if len(vals)!=len(original_labels):
        if strict_lengths:
            raise ValueError(f'HBA subject {pid}: spectra={len(vals)} != l.csv={len(original_labels)}; source did silently truncate. Review alignment or use --allow-length-trim to match original code.')
        n=min(len(vals),len(original_labels));vals=vals[:n];original_labels=original_labels[:n]
    # HBA *_l.csv contains 0 (unconscious), 1 (awake), and NaN (unknown).
    # Unknown is NOT a valid negative/positive label and must never be cast to int.
    valid=np.isfinite(original_labels)
    if not np.isin(original_labels[valid],[0,1]).all():
        unexpected=np.unique(original_labels[valid][~np.isin(original_labels[valid],[0,1])])
        raise ValueError(f'HBA subject {pid}: unexpected finite labels: {unexpected}')
    if not valid.any():raise ValueError(f'HBA subject {pid}: no labeled rows')
    # Reproduce the historical HBA alpha-score recipe before masking: feature-wise
    # StandardScaler across the subject's full original spectra, columns 16:24.
    # This is for LABEL DERIVATION only, NOT the benchmark model input scaler.
    raw=np.nan_to_num(vals[:,:40].astype(np.float32),nan=0.0,posinf=0.0,neginf=0.0)
    std=StandardScaler().fit_transform(raw)
    score=np.mean(std[:,16:24],axis=1)
    unconscious=(original_labels==0)
    if not unconscious.any():raise ValueError(f'HBA subject {pid}: no valid unconscious rows for median')
    median=float(np.median(score[unconscious]))
    original_indices=np.flatnonzero(valid).astype(np.int64)
    orig=original_labels[valid].astype(np.int64)
    y=np.where(orig==1,0,np.where(score[valid]>=median,1,2)).astype(np.int64)
    metadata={'sdb_sha256':_digest(f),'label_sha256':_digest(g),
              'spectral_columns':int(vals.shape[1]),
              'n_total_rows':int(len(original_labels)),
              'n_missing_annotation_rows':int((~valid).sum()),
              'n_valid_annotation_rows':int(valid.sum())}
    return raw[valid],y,orig,score[valid],median,metadata,original_indices


def export_hba(hba_source,data_root,stride=1,allow_length_trim=False):
    hba_source=Path(hba_source)
    root=Path(data_root)/'HBA';dest=root/'incoming';_check_output(dest)
    files=sorted(hba_source.glob('*_Sdb.csv'))
    if not files:raise FileNotFoundError(f'No <subject>_Sdb.csv in {hba_source}')
    ids=[p.name[:-len('_Sdb.csv')] for p in files]
    absent=[str(hba_source/f'{sid}_l.csv') for sid in ids if not (hba_source/f'{sid}_l.csv').exists()]
    if absent:raise FileNotFoundError(f'Missing matching labels: {absent[:8]}')
    labels=[];summary=[]
    for sid in ids:
        x,y,orig,score,med,src,row_idx=_load_hba_subject(hba_source,sid,not allow_length_trim)
        seq,ends=_windows(x,y,row_idx,f'HBA:{sid}',stride=stride)
        seq['label_schema']=np.array(SCHEMA_ID)
        np.savez_compressed(dest/f'{sid}.npz',**seq)
        summary.append(dict(subject_id=sid,n_source=len(y),n_sequences=len(ends),label0=int((y==0).sum()),label1=int((y==1).sum()),label2=int((y==2).sum()),median=med,**src))
        labels.extend(dict(subject_id=sid,original_row=int(row_idx[i]),original_state=int(orig[i]),alpha_score=float(score[i]),subject_median=med,label=int(y[i])) for i in range(len(y)))
    pd.DataFrame(labels).to_csv(root/'HBA_three_class_labels.csv',index=False)
    pd.DataFrame(summary).to_csv(root/'source_audit.csv',index=False)
    write_json(root/'dataset_label_rules.json',{
        'source':'Adapted old HBA training code; unknown labels skipped',
        'labels':{'0':'Awake','1':'Optimal','2':'Excessive'},
        'alpha_score':'historical StandardScaler over full subject, columns 16:24 (not necessarily final manuscript alpha calculation)',
        'warning':'HBA alpha-score derivation uses historical feature columns/full-subject standardization; manuscript equivalence is NOT verified. Class IDs are canonical.',
        'stride':int(stride)})
    write_schema(root,dataset='HBA',source=str(hba_source),extra={'alpha_recipe':'historical feature columns 16:24 full-subject standardization; pending strict manuscript audit'})
    return {'subjects':len(ids),'sequences':int(sum(x['n_sequences'] for x in summary)),'destination':str(dest)}

