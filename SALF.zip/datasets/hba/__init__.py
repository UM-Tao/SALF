"""HBA dataset-specific input processing."""
