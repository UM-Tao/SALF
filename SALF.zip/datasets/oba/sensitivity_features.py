"""OBA early RF feature adapter: verify an externally extracted first-10-min five-feature table.
This does NOT invent IES/alpha onset features from 20x40 DoA PSD. Raw EEG feature extraction is not in the source package.
"""
from pathlib import Path
import pandas as pd
from SALF.data.grouping import ID_CANDIDATES
FEATURES=('t_IES_1','t_IES_2','t_alpha_1','t_alpha_2','entropy')

def validate_feature_table(source,output):
    p=Path(source);d=pd.read_excel(p) if p.suffix.lower() in ('.xlsx','.xls') else pd.read_csv(p)
    idcol=next((c for c in ID_CANDIDATES if c in d.columns),None)
    if idcol is None:raise ValueError('Need a subject ID column')
    absent=[c for c in FEATURES if c not in d]
    if absent:raise ValueError(f'Missing OBA early onset/entropy features: {absent}; provide the actual first-10-min EEG feature extraction results')
    if d[idcol].astype(str).duplicated().any():raise ValueError('Repeated subject ID')
    numeric=d[list(FEATURES)].apply(pd.to_numeric,errors='coerce')
    if numeric.isna().all(axis=0).any():raise ValueError('An entire early RF feature column is empty')
    out=Path(output);out.parent.mkdir(parents=True,exist_ok=True)
    d.to_csv(out,index=False)
    print('OBA validated first-10-min RF features:',out)
    return out
