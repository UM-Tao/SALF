"""OBA dataset-specific input processing."""
