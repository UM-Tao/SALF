"""OBA RASS-derived DoA labels: expects source labels already encoded as canonical.
Use --source-label-order legacy only for independently verified reversed sources.
Early RF phenotype target (S/NS) is a SEPARATE 30-min IES label.
"""
from SALF.data.labels import CLASS_NAMES, convert_labels
DATASET='OBA'
SOURCE_RASS_MAPPING='Inherited labels from source psdata/label TXT; review original clinical RASS mapping'
