# Modularity refactor: bodies below extracted from original source without changing training equations.
import torch
from torch import nn
from .common import AttnLayer
class GraphAttentionEncoder(nn.Module):
    def __init__(self,n_heads=8,embed_dim=128,n_layers=3,node_dim=40,normalization='batch',feed_forward_hidden=512):
        super().__init__(); self.init_embed=nn.Linear(node_dim,embed_dim) if node_dim is not None else None
        self.layers=nn.Sequential(*[AttnLayer(n_heads,embed_dim,feed_forward_hidden,normalization) for _ in range(n_layers)])
    def forward(self,x,mask=None):
        if mask is not None: raise NotImplementedError
        h=self.init_embed(x.view(-1,x.size(-1))).view(*x.size()[:2],-1) if self.init_embed is not None else x
        h=self.layers(h); return h,h.mean(dim=1)

class GraphAttentionClassifier(nn.Module):
    def __init__(self,input_dim=40,embedding_dim=128,n_heads=8,n_layers=3,output_size=3,feed_forward_hidden=512):
        super().__init__(); self.encoder=GraphAttentionEncoder(n_heads,embedding_dim,n_layers,input_dim,'batch',feed_forward_hidden); self.fc=nn.Linear(embedding_dim,output_size)
    def forward(self,x,return_mid=False):
        _,mid=self.encoder(x); logits=self.fc(mid); return (logits,mid) if return_mid else logits

class SALFSourceGraph(nn.Module):
    def __init__(self):
        super().__init__();self.net=GraphAttentionClassifier(40,128,8,3,3,512)
    def forward(self,x,raw=None):return self.net(x,return_mid=True)
