# Modularity refactor: bodies below extracted from original source without changing training equations.
import math
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
class SkipConnection(nn.Module):
    def __init__(self,module): super().__init__(); self.module=module
    def forward(self,x): return x+self.module(x)

class CustomMHA(nn.Module):
    def __init__(self,n_heads,input_dim,embed_dim,val_dim=None,key_dim=None):
        super().__init__(); val_dim=val_dim or embed_dim//n_heads; key_dim=key_dim or val_dim
        self.n_heads=n_heads; self.input_dim=input_dim; self.embed_dim=embed_dim; self.val_dim=val_dim; self.key_dim=key_dim
        self.norm_factor=1/math.sqrt(key_dim)
        self.W_query=nn.Parameter(torch.Tensor(n_heads,input_dim,key_dim)); self.W_key=nn.Parameter(torch.Tensor(n_heads,input_dim,key_dim))
        self.W_val=nn.Parameter(torch.Tensor(n_heads,input_dim,val_dim)); self.W_out=nn.Parameter(torch.Tensor(n_heads,val_dim,embed_dim))
        for p in self.parameters(): p.data.uniform_(-1/math.sqrt(p.size(-1)),1/math.sqrt(p.size(-1)))
    def forward(self,q,h=None,mask=None):
        if h is None: h=q
        B,N,D=h.size(); QN=q.size(1)
        hf=h.contiguous().view(-1,D); qf=q.contiguous().view(-1,D)
        shp=(self.n_heads,B,N,-1); shpq=(self.n_heads,B,QN,-1)
        Q=torch.matmul(qf,self.W_query).view(shpq); K=torch.matmul(hf,self.W_key).view(shp); V=torch.matmul(hf,self.W_val).view(shp)
        comp=self.norm_factor*torch.matmul(Q,K.transpose(2,3))
        if mask is not None:
            mask=mask.view(1,B,QN,N).expand_as(comp); comp=comp.masked_fill(mask,-np.inf)
        attn=torch.softmax(comp,dim=-1)
        if mask is not None: attn=attn.masked_fill(mask,0.0)
        heads=torch.matmul(attn,V)
        return torch.mm(heads.permute(1,2,0,3).contiguous().view(-1,self.n_heads*self.val_dim),self.W_out.view(-1,self.embed_dim)).view(B,QN,self.embed_dim)

class Norm(nn.Module):
    def __init__(self,embed_dim,normalization='batch'):
        super().__init__()
        if normalization=='batch': self.n=nn.BatchNorm1d(embed_dim)
        elif normalization=='instance': self.n=nn.InstanceNorm1d(embed_dim,affine=True)
        elif normalization=='layer': self.n=nn.LayerNorm(embed_dim)
        elif normalization is None: self.n=None
        else: raise ValueError(normalization)
    def forward(self,x):
        if self.n is None: return x
        if isinstance(self.n,nn.BatchNorm1d): return self.n(x.view(-1,x.size(-1))).view(*x.size())
        if isinstance(self.n,nn.InstanceNorm1d): return self.n(x.permute(0,2,1)).permute(0,2,1)
        return self.n(x)

class AttnLayer(nn.Sequential):
    def __init__(self,n_heads,embed_dim,ff=512,normalization='batch'):
        super().__init__(SkipConnection(CustomMHA(n_heads,embed_dim,embed_dim)),Norm(embed_dim,normalization),
                         SkipConnection(nn.Sequential(nn.Linear(embed_dim,ff),nn.ReLU(),nn.Linear(ff,embed_dim))),Norm(embed_dim,normalization))
