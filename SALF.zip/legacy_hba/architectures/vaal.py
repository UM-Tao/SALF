import torch
from torch import nn
from torch.nn import functional as F

class VAALClassifier(nn.Module):
    def __init__(self,input_dim=40,seq_len=20,z_dim=32,output_size=3):
        super().__init__(); self.seq_len=seq_len
        self.encoder=nn.Sequential(
            nn.Conv1d(input_dim,16,3,1,1,bias=False),nn.BatchNorm1d(16),nn.ReLU(True),
            nn.Conv1d(16,32,3,1,1,bias=False),nn.BatchNorm1d(32),nn.ReLU(True),
            nn.Conv1d(32,64,3,1,1,bias=False),nn.BatchNorm1d(64),nn.ReLU(True))
        self.fc_latent=nn.Linear(64*seq_len,z_dim); self.dropout=nn.Dropout(0.1); self.classifier=nn.Linear(z_dim,output_size)
    def forward(self,x,return_mid=False):
        h=self.encoder(x.transpose(1,2)); mid=F.relu(self.fc_latent(h.contiguous().view(h.size(0),-1))); logits=self.classifier(self.dropout(mid))
        return (logits,mid) if return_mid else logits
