"""Training-only HBA historical-architecture trainer; refactored (not original historical CV script).
Uses original model, HBA data reader, hyperparameters and supervised mini-batch logic.
No held-out outer test inference or plots.
"""
import copy
import json
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch import nn,optim
from sklearn.model_selection import KFold
from sklearn.metrics import accuracy_score
from .config import SEED,TRAIN_CONFIG
from SALF.data.io import load_metadata
from .data import load_hba_raw_data,make_loader
from .models import build_model

def train_historical_base(backbone,group,data_root,output,inner_fold=1,device='cuda:0',epochs=None,group_data_root=None):
    if backbone not in ('transformer','lstm','graph','vaal'):raise ValueError(backbone)
    if group not in ('sen','nonsen'):raise ValueError(group)
    if not 1<=inner_fold<=5:raise ValueError('inner_fold must be 1..5')
    if not group_data_root:raise ValueError('HBA grouped root required')
    df=load_metadata(group_data_root,'HBA')
    pids=df.loc[df.phenotype==('S' if group=='sen' else 'NS'),'subject_id'].astype(str).tolist()
    d,ids=load_hba_raw_data(pids,str(data_root));ids=np.array(ids)
    if len(ids)<5:raise ValueError('Insufficient HBA subject files')
    tr_idx,va_idx=list(KFold(5,shuffle=True,random_state=SEED).split(ids))[inner_fold-1]
    train_loader=make_loader(ids[tr_idx],d,True);val_loader=make_loader(ids[va_idx],d,False)
    if not train_loader or not val_loader:raise ValueError('Empty HBA loaders')
    torch.manual_seed(SEED+inner_fold)
    m=build_model(backbone).to(device);op=optim.Adam(m.parameters(),lr=TRAIN_CONFIG['lr'])
    crit=nn.CrossEntropyLoss();best=-1;state=None;bad=0;history=[]
    for e in range(1,(epochs or TRAIN_CONFIG['n_epochs'])+1):
        m.train();ls=0.;n=0
        for x,y in train_loader:
            x=x.to(device);y=y.to(device);op.zero_grad();z=m(x);loss=crit(z,y)
            loss.backward();op.step();ls+=loss.item()*len(y);n+=len(y)
        m.eval(); ys=[];ps=[]
        with torch.no_grad():
            for x,y in val_loader:
                z=m(x.to(device));ys.extend(y.tolist());ps.extend(z.argmax(1).cpu().tolist())
        score=accuracy_score(ys,ps);history.append({'epoch':e,'loss':ls/max(1,n),'val_acc':score})
        if score>best:best=score;state=copy.deepcopy(m.state_dict());bad=0
        else:bad+=1
        if bad>=TRAIN_CONFIG['patience']:break
    folder=Path(output)/group/backbone/f'inner_{inner_fold:02d}';folder.mkdir(parents=True,exist_ok=True)
    torch.save({'state_dict':state,'model_type':backbone,'train_config':TRAIN_CONFIG,'best_val_acc':best},folder/'best_model.pth')
    pd.DataFrame(history).to_csv(folder/'history.csv',index=False)
    (folder/'training.json').write_text(json.dumps({'group':group,'backbone':backbone,'train_subjects':ids[tr_idx].tolist(),'val_subjects':ids[va_idx].tolist(),'source':'NEW modular training stage using historical HBA architecture/data, not an exact historical run'},indent=2),encoding='utf-8')
    print('Saved',folder/'best_model.pth')
