"""Original legacy HBA model factory; class bodies in architectures/*.py."""
from .config import TRAIN_CONFIG
from .architectures.lstm import LSTMClassifier
from .architectures.graph import GraphAttentionClassifier
from .architectures.transformer import TransformerClassifier
from .architectures.vaal import VAALClassifier

def build_model(model_type):
    if model_type=='lstm': return LSTMClassifier(40,TRAIN_CONFIG['lstm_hidden'],3,TRAIN_CONFIG['lstm_layers'],20)
    if model_type=='graph': return GraphAttentionClassifier(40,TRAIN_CONFIG['graph_embed'],TRAIN_CONFIG['graph_heads'],TRAIN_CONFIG['graph_layers'],3,TRAIN_CONFIG['graph_ff'])
    if model_type=='transformer': return TransformerClassifier(40,TRAIN_CONFIG['transformer_embed'],TRAIN_CONFIG['transformer_heads'],TRAIN_CONFIG['transformer_layers'],20,3,TRAIN_CONFIG['transformer_ff'])
    if model_type=='vaal': return VAALClassifier(40,20,TRAIN_CONFIG['vaal_latent'],3)
    raise ValueError(model_type)

def count_parameters(model): return sum(p.numel() for p in model.parameters() if p.requires_grad)
