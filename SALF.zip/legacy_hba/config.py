"""Historical HBA network hyperparameters; phenotype IDs read from dataset folders."""
SEED = 42
TRAIN_CONFIG = {
    'n_epochs':100,'batch_size':64,'eval_batch_size':256,'lr':1e-4,'patience':20,
    'seq_len':20,'input_dim':40,'n_classes':3,
    'lstm_hidden':256,'lstm_layers':2,
    'graph_embed':128,'graph_heads':8,'graph_layers':3,'graph_ff':512,
    'transformer_embed':128,'transformer_heads':8,'transformer_layers':3,'transformer_ff':512,
    'vaal_latent':32,
}

# Transformer KD configuration: kept consistent with the previous HBA KD code.
KD_CONFIG = {
    'n_epochs': 100,
    'batch_size': 64,
    'eval_batch_size': 256,
    'lr': 5e-5,
    'patience': 15,
    'T': 2.0,
    'alpha': 0.75,   # soft KL
    'gamma': 0.20,   # hard CE
    'beta': 0.05,    # feature MSE
}
