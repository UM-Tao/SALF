"""Original HBA per-subject StandardScaler and alpha-based labeling; NOT the R1C5 standardized preprocessing.
Training directly from these functions may produce DIFFERENT data/labels from the final manuscript.
"""
import os
import numpy as np
import pandas as pd
import torch
import torch.utils.data as Data
from sklearn.preprocessing import StandardScaler
from .config import SEED
def load_hba_raw_data(pids,data_root):
    raw_data={}; valid_ids=[]
    for pid in pids:
        sdb=os.path.join(data_root,f'{pid}_Sdb.csv'); lab=os.path.join(data_root,f'{pid}_l.csv')
        if not (os.path.exists(sdb) and os.path.exists(lab)):
            print(f'  ⚠️ missing PID={pid}'); continue
        try:
            df=pd.read_csv(sdb,header=None); arr=df.values if df.shape[0]>df.shape[1] else df.values.T
            features_raw=np.nan_to_num(arr[:,:40],nan=0.0,posinf=0.0,neginf=0.0)
            features=StandardScaler().fit_transform(features_raw)
            orig=pd.read_csv(lab,header=None).values.flatten(); n=min(len(features),len(orig)); features=features[:n]; orig=orig[:n]
            new=np.zeros(n,dtype=np.int64); unconscious=(orig==0)
            alpha_threshold=float(np.median(np.mean(features[unconscious,16:24],axis=1))) if unconscious.any() else 0.0
            awake=(orig==1); new[awake]=0
            for i in np.where(~awake)[0]: new[i]=1 if float(np.mean(features[i,16:24]))>=alpha_threshold else 2
            if len(features)>25: raw_data[pid]=(features.astype(np.float32),new); valid_ids.append(pid)
        except Exception as e: print(f'  ❌ PID {pid}: {type(e).__name__}: {e}')
    return raw_data,valid_ids

def slide_window(pids,data_dict):
    X,Y=[],[]; L=20
    for pid in pids:
        x,y=data_dict[pid]
        for i in range(len(x)-L): X.append(x[i:i+L]); Y.append(y[i+L-1])
    return torch.FloatTensor(np.asarray(X,dtype=np.float32)),torch.LongTensor(np.asarray(Y,dtype=np.int64))

def make_loader(pids,data_dict,train=False):
    x,y=slide_window(pids,data_dict)
    if len(y)==0: return None
    g=torch.Generator(); g.manual_seed(SEED)
    return Data.DataLoader(Data.TensorDataset(x,y),batch_size=64 if train else 256,shuffle=train,generator=g if train else None,num_workers=0,pin_memory=torch.cuda.is_available())
