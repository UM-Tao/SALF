"""Historical HBA Transformer KD weights; NEW training-only adaptation of original objective.
The original legacy KD experiment also included teacher selection and test comparisons;
those are intentionally not included. Teacher/base must use same inner fold.
"""
import copy,json
from pathlib import Path
import torch
from torch import nn,optim
from torch.nn import functional as F
import pandas as pd
from sklearn.metrics import accuracy_score
from .config import KD_CONFIG,SEED
from SALF.data.io import load_metadata
from .data import load_hba_raw_data,make_loader
from .models import build_model
from sklearn.model_selection import KFold
import numpy as np

def train_transformer_kd(data_root,teacher_checkpoint,base_checkpoint,output,inner_fold=1,device='cuda:0',epochs=None,group_data_root=None):
    if not 1<=inner_fold<=5:raise ValueError('inner_fold must be 1..5')
    teacher=build_model('transformer').to(device)
    base=build_model('transformer').to(device)
    for m,p in [(teacher,teacher_checkpoint),(base,base_checkpoint)]:
        ck=torch.load(p,map_location=device,weights_only=True)
        m.load_state_dict(ck.get('state_dict',ck))
    teacher.eval()
    for p in teacher.parameters():p.requires_grad_(False)
    if not group_data_root:raise ValueError('HBA grouped root required')
    subjects=load_metadata(group_data_root,'HBA')
    pids=subjects.loc[subjects.phenotype=='NS','subject_id'].astype(str).tolist()
    d,ids=load_hba_raw_data(pids,str(data_root));ids=np.array(ids)
    tr,va=list(KFold(5,shuffle=True,random_state=SEED).split(ids))[inner_fold-1]
    loader=make_loader(ids[tr],d,True);val=make_loader(ids[va],d,False)
    model=build_model('transformer').to(device);model.load_state_dict(copy.deepcopy(base.state_dict()))
    opt=optim.Adam(model.parameters(),lr=KD_CONFIG['lr'])
    best=-1;best_state=None;bad=0;hist=[];T=KD_CONFIG['T']
    for ep in range(1,(epochs or KD_CONFIG['n_epochs'])+1):
        model.train();loss_sum=0.;n=0
        for x,y in loader:
            x=x.to(device);y=y.to(device)
            student_logits,student_mid=model(x,return_mid=True)
            with torch.no_grad():teacher_logits,teacher_mid=teacher(x,return_mid=True)
            hard=F.cross_entropy(student_logits,y)
            soft=F.kl_div(F.log_softmax(student_logits/T,dim=1),F.softmax(teacher_logits/T,dim=1),reduction='batchmean')*(T*T)
            feat=F.mse_loss(student_mid,teacher_mid)
            loss=KD_CONFIG['gamma']*hard+KD_CONFIG['alpha']*soft+KD_CONFIG['beta']*feat
            opt.zero_grad();loss.backward();opt.step()
            loss_sum+=loss.item()*len(y);n+=len(y)
        model.eval();ys=[];ps=[]
        with torch.no_grad():
            for x,y in val:
                z=model(x.to(device));ys+=y.tolist();ps+=z.argmax(1).cpu().tolist()
        score=accuracy_score(ys,ps);hist.append({'epoch':ep,'train_kd_loss':loss_sum/max(1,n),'val_acc':score})
        if score>best:best=score;best_state=copy.deepcopy(model.state_dict());bad=0
        else:bad+=1
        if bad>=KD_CONFIG['patience']:break
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    torch.save({'state_dict':best_state,'best_val_acc':best,'teacher_checkpoint':str(teacher_checkpoint),'base_checkpoint':str(base_checkpoint),'kd_config':KD_CONFIG},output/'best_kd_model.pth')
    pd.DataFrame(hist).to_csv(output/'history.csv',index=False)
    print('Saved',output/'best_kd_model.pth')
