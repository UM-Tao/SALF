"""Subject NPZ reader with folder-based S/NS discovery (no frozen cohort arrays)."""
import csv, hashlib, io, json, re, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import KFold
from .grouping import scan_grouped, save_scan, digest
from .labels import verify_schema,SCHEMA_ID

def sha(path):return digest(path)

def write_json(path,data):
 p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(data,indent=2,ensure_ascii=False,sort_keys=True),encoding='utf-8')

def load_metadata(root,dataset):
 """Always scan real S/NS folders; validate any saved subjects.csv against disk."""
 return scan_grouped(root,dataset)

def check_frozen_cohort(root,dataset,df):
 """Compatibility name: no historical IDs/counts; require folder/file mapping only."""
 real=scan_grouped(root,dataset)
 need=['subject_id','phenotype','file']
 if not df[need].sort_values(need).reset_index(drop=True).equals(real[need].sort_values(need).reset_index(drop=True)):
  raise ValueError('Subject/file assignment changed')
 if df.phenotype.value_counts().min()<10:
  raise ValueError('10-fold study requires >=10 S and >=10 NS distinct subjects; use a larger cohort (not the historical fixed counts)')
 return True

def check_npz(root,dataset,df,strict=True):
 found=set(); ledger=[]; shapes=set(); raw_shapes=set(); prohibited=False
 for row in df.itertuples():
  path=Path(root)/dataset/row.file
  with np.load(path,allow_pickle=False) as z:
   for key in ('x_psd','y','case_ids'):
    if key not in z:raise ValueError(f'{path}: missing {key}')
   x,y,ids=z['x_psd'],z['y'],z['case_ids'].astype(str)
   if x.ndim!=3 or x.shape[1:]!=(20,40):raise ValueError(f'{path}: x_psd must [N,20,40]; got {x.shape}')
   if len(x)!=len(y) or len(x)!=len(ids):raise ValueError(f'{path}: inconsistent cases')
   if len(x)<1:raise ValueError(f'{path}: empty subject')
   if not np.isfinite(x).all():raise ValueError(f'{path}: nonfinite PSD; audit preprocessing first')
   if not np.issubdtype(y.dtype,np.integer) or not set(np.unique(y)).issubset({0,1,2}):raise ValueError(f'{path}: labels must be integer 0,1,2')
   if 'label_schema' in z and str(z['label_schema'].item())!=SCHEMA_ID:raise ValueError(f'{path}: non-canonical label_schema')
   if len(ids)!=len(set(ids.tolist())):raise ValueError(f'{path}: duplicate case ids')
   if not all(xid.startswith(f'{dataset}:{row.subject_id}:') for xid in ids):
    raise ValueError(f'{path}: case ID must begin {dataset}:{row.subject_id}: to audit subject mapping')
   if any(xid in found for xid in ids):raise ValueError(f'{path}: duplicated global case IDs')
   found.update(ids.tolist());shapes.add(tuple(x.shape[1:])); hasraw='x_raw' in z
   if hasraw:
    raw=z['x_raw']; raw_shapes.add(tuple(raw.shape[1:]))
    if raw.ndim!=3 or raw.shape[0]!=len(x) or raw.shape[-1]!=3840 or raw.shape[1] not in (1,2):raise ValueError(f'{path}: x_raw shape [N,1/2,3840] required, fs=128, trailing 30s')
    if not np.isfinite(raw).all():raise ValueError(f'{path}: nonfinite raw')
   if ('window_start' in z) != ('window_end' in z):
    raise ValueError(f'{path}: window_start and window_end must be provided together')
   if 'window_start' in z:
    starts,ends=z['window_start'],z['window_end']
    if starts.shape!=(len(x),) or ends.shape!=(len(x),):raise ValueError(f'{path}: window_start/end must be [N]')
    if not np.isfinite(starts).all() or not np.isfinite(ends).all() or np.any(ends<starts):raise ValueError(f'{path}: invalid window boundaries')
   ledger.append(dict(dataset=dataset,subject_id=str(row.subject_id),phenotype=row.phenotype,n_cases=len(x),n0=int((y==0).sum()),n1=int((y==1).sum()),n2=int((y==2).sum()),has_raw=hasraw,has_window_bounds=('window_start' in z),file_sha256=sha(path)))
   if str(row.source).strip().lower() in ('synthetic','demo','fake'):prohibited=True
 if len(raw_shapes)>1:raise ValueError(f'{dataset}: inconsistent raw shapes {raw_shapes}; harmonize channels BEFORE training')
 if strict and prohibited:raise ValueError('Synthetic/demo data forbidden for FORMAL results')
 return pd.DataFrame(ledger),len(raw_shapes)==1

def cache_dataset(root,dataset,df,subjects,max_per_subject=0):
 sample=[]
 lookup={str(r.subject_id):r for r in df.itertuples()}
 for sid in subjects:
  r=lookup[str(sid)]
  with np.load(Path(root)/dataset/r.file,allow_pickle=False) as z:
   n=len(z['y']); idx=np.arange(n)
   if max_per_subject:idx=idx[:max_per_subject]
   part={'X':z['x_psd'][idx].astype('float32'), 'y':z['y'][idx].astype('int64'), 'id':z['case_ids'][idx].astype(str), 'sid':np.full(len(idx),str(sid)), 'phen':np.full(len(idx),r.phenotype)}
   for key in ('window_start','window_end'):
    if key in z: part[key]=z[key][idx]
   if 'x_raw' in z:part['raw']=z['x_raw'][idx].astype('float32')
   sample.append(part)
 keys=set(sample[0])
 if any(set(s)!=keys for s in sample):
  # If real raw absent for some subjects, all models use spectral adaptation, but no subjects get removed.
  keys-= {'raw'}
  # Optional boundaries must be present in ALL included subjects or are dropped
  # for this group. Such missing metadata must be fixed before claiming time alignment.
  keys=set.intersection(*(set(s.keys()) for s in sample))
 return {k:np.concatenate([s[k] for s in sample],axis=0) for k in keys}

def split_all(df,seed=42,k=10):
 by={p:sorted(df.loc[df.phenotype==p,'subject_id'].astype(str).tolist()) for p in ('S','NS')}
 if any(len(v)<k for v in by.values()):raise ValueError(f'Need >= {k} subjects per phenotype for 10 folds')
 foldsets={p:list(KFold(n_splits=k,shuffle=True,random_state=seed).split(np.array(v))) for p,v in by.items()}
 out=[]
 for j in range(k):
  for p in ('S','NS'):
   ss=by[p]; tr,te=foldsets[p][j]
   for pos in tr:out.append(dict(outer=j+1,subject_id=ss[pos],phenotype=p,role='development'))
   for pos in te:out.append(dict(outer=j+1,subject_id=ss[pos],phenotype=p,role='test'))
 return pd.DataFrame(out)

def split_file(path,df,seed):
 path=Path(path)
 if path.exists():
  s=pd.read_csv(path,dtype={'subject_id':str,'phenotype':str,'role':str})
  expected=split_all(df,seed)
  if not s.equals(expected):raise ValueError(f'FROZEN split {path} disagrees with requested cohort/seed; no overwrite. New output dir required.')
 else:
  path.parent.mkdir(parents=True,exist_ok=True)
  s=split_all(df,seed);s.to_csv(path,index=False)
 return s

def get_fold(s,k):
 t=s.loc[(s.outer==k)&(s.role=='test')];d=s.loc[(s.outer==k)&(s.role=='development')]
 a=set(t.subject_id);b=set(d.subject_id)
 if a & b or len(a|b)!=len(s.subject_id.unique()):raise ValueError('Subject leakage / missing subjects')
 return d.subject_id.astype(str).tolist(), t.subject_id.astype(str).tolist()
